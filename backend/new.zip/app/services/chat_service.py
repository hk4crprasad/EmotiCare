from langchain_openai import AzureChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage, AIMessage
from langchain_core.tools import tool
from langgraph.prebuilt import create_react_agent
from langgraph.checkpoint.memory import MemorySaver
from langchain_mcp_adapters.client import MultiServerMCPClient
from typing import List, Dict, Any, Tuple, Optional
import re
import json
import logging
import asyncio
from datetime import datetime

from app.config import settings
from app.schemas.chat import ChatMessage, ChatResponse, EmotionalState
from app.database import get_database
from app.services.notification_service import notification_service

logger = logging.getLogger(__name__)

# Mental Health Tools for React Agent
@tool
def get_breathing_exercise() -> str:
    """Provides a simple breathing exercise for anxiety and stress relief"""
    return """Try this 4-7-8 breathing technique:
1. Inhale through your nose for 4 counts
2. Hold your breath for 7 counts  
3. Exhale through your mouth for 8 counts
4. Repeat 3-4 times
This activates your parasympathetic nervous system and promotes calm."""

@tool
def get_grounding_technique() -> str:
    """Provides a 5-4-3-2-1 grounding technique for anxiety and panic"""
    return """Use the 5-4-3-2-1 grounding technique:
- 5 things you can SEE around you
- 4 things you can TOUCH 
- 3 things you can HEAR
- 2 things you can SMELL
- 1 thing you can TASTE
This helps bring you back to the present moment and reduces anxiety."""

@tool
def get_study_tips() -> str:
    """Provides evidence-based study tips for academic stress"""
    return """Effective study strategies:
1. Pomodoro Technique: 25min study + 5min break
2. Active recall: Test yourself instead of re-reading
3. Spaced repetition: Review material at increasing intervals
4. Break large tasks into smaller, manageable chunks
5. Create a consistent study schedule
6. Find a quiet, dedicated study space"""

@tool
def assess_crisis_risk(user_message: str) -> str:
    """Assesses if the user needs immediate crisis intervention"""
    crisis_keywords = [
        "suicide", "kill myself", "end it all", "can't go on", 
        "self-harm", "hurt myself", "no point", "better off dead"
    ]
    
    if any(keyword in user_message.lower() for keyword in crisis_keywords):
        return """CRISIS ALERT: Please reach out for immediate support:
• National Suicide Prevention Lifeline: 988
• Crisis Text Line: Text HOME to 741741
• Emergency Services: 911
• Campus Crisis Hotline: Available 24/7
You are not alone, and help is available right now."""
    
    return "No immediate crisis indicators detected."

@tool
def check_appointment_availability() -> str:
    """Checks if counseling appointments are available"""
    # For now, return a simple availability message
    # In production, this would check actual database
    return "Good news! We have counselors available. You can book an appointment through the platform or contact us directly for urgent needs."

async def setup_mcp_client():
    """Setup MCP client and get tools"""
    try:
        client = MultiServerMCPClient({
            "math": {
                "transport": "sse",
                "url": "http://localhost:8001/sse"
            },
        })
        mcp_tools = await client.get_tools()
        return mcp_tools
    except Exception as e:
        logger.warning(f"Failed to setup MCP client: {e}. Continuing with base tools only.")
        return []

class MentalHealthChatService:
    """AI-powered mental health chat service using Azure OpenAI with React Agent"""
    
    def __init__(self):
        # Initialize React agent (will be setup async)
        self.agent_executor = None
        self.tools = None
        self.conversations = {}
        
        # Main LLM for React agent
        self.llm = AzureChatOpenAI(
            azure_endpoint=settings.AZURE_OPENAI_ENDPOINT,
            azure_deployment=settings.AZURE_OPENAI_DEPLOYMENT,
            api_key=settings.AZURE_OPENAI_API_KEY,
            api_version=settings.AZURE_OPENAI_API_VERSION,
            temperature=0.7,
            max_tokens=1000
        )
        
        # Analysis LLM for root cause analysis with higher creativity
        self.analysis_llm = AzureChatOpenAI(
            azure_endpoint=settings.AZURE_OPENAI_ENDPOINT,
            azure_deployment=settings.AZURE_OPENAI_DEPLOYMENT,
            api_key=settings.AZURE_OPENAI_API_KEY,
            api_version=settings.AZURE_OPENAI_API_VERSION,
            temperature=0.3,  # Lower temperature for analysis
            max_tokens=500
        )
        
        # System message for mental health support
        self.system_message = SystemMessage(content="""You are a compassionate AI mental health assistant for EmotiCare, a university counseling platform.

CORE PRINCIPLES:
1. EMPATHY: Always acknowledge and validate feelings
2. SAFETY: Prioritize user safety and crisis intervention  
3. SUPPORT: Provide practical coping strategies
4. BOUNDARIES: Never diagnose or replace professional therapy
5. EVIDENCE-BASED: Use proven techniques and tools
6. CONTINUITY: Remember and reference previous parts of our conversation

RESPONSE GUIDELINES:
- Use warm, understanding language
- Keep responses concise (under 150 words for voice, longer for text if needed)
- Ask thoughtful follow-up questions
- ALWAYS use available tools when appropriate to provide specific techniques
- Encourage professional help when needed
- Be culturally sensitive and inclusive

TOOL USAGE INSTRUCTIONS:
- When user mentions anxiety, stress, or panic: USE get_breathing_exercise or get_grounding_technique tools
- When user asks about studying or academic stress: USE get_study_tips tool
- When user mentions harm, suicide, or crisis words: IMMEDIATELY USE assess_crisis_risk tool
- When user asks about counseling appointments: USE check_appointment_availability tool
- When user asks for story creation: USE create_story_job_mcp tool
- When user asks about job status: USE get_job_status_mcp tool

You MUST use the appropriate tools to provide specific, helpful techniques rather than general advice.

If crisis indicators are detected, IMMEDIATELY use the assess_crisis_risk tool and prioritize safety.""")
        
        # Initialize crisis detection data
        self.__init_crisis_data()
    
    async def get_react_agent(self):
        """Get or initialize the React agent asynchronously"""
        if self.agent_executor is None:
            # Setup tools
            base_tools = [
                get_breathing_exercise,
                get_grounding_technique,
                get_study_tips,
                assess_crisis_risk,
                check_appointment_availability
            ]
            
            # Get MCP tools
            mcp_tools = await setup_mcp_client()
            self.tools = base_tools + mcp_tools
            
            # Enable verbose logging for agent execution
            from langchain.globals import set_verbose
            set_verbose(True)
            
            # Create React Agent with memory
            memory = MemorySaver()
            self.agent_executor = create_react_agent(
                self.llm, 
                self.tools, 
                checkpointer=memory
            )
            
            logger.info(f"React Agent initialized with {len(self.tools)} tools")
            logger.info(f"Available tools: {[tool.name for tool in self.tools]}")
        
        return self.agent_executor
        
    async def generate_chat_title(self, first_user_message: str, first_ai_response: str) -> str:
        """Generate a short, descriptive title for the chat session"""
        try:
            title_prompt = f"""
Based on this initial conversation, generate a very short, descriptive title (3-6 words) that captures the main topic or concern:

User: {first_user_message[:200]}
Assistant: {first_ai_response[:200]}

Generate only the title, nothing else. Examples:
- "Exam Anxiety Support"
- "Study Stress Help"
- "Depression Support"
- "Sleep Issues Discussion"
- "Career Guidance Chat"

Title:"""
            
            response = await self.analysis_llm.ainvoke([
                SystemMessage(content="You are a helpful assistant that creates short, meaningful titles for mental health conversations."),
                HumanMessage(content=title_prompt)
            ])
            
            title = response.content.strip().replace('"', '').replace("'", "")
            # Ensure title is not too long
            if len(title) > 40:
                title = title[:37] + "..."
            
            return title if title else "Mental Health Support"
            
        except Exception as e:
            logger.error(f"Error generating chat title: {e}")
            # Fallback: extract keywords from user message
            keywords = ["anxiety", "depression", "stress", "exam", "sleep", "study", "help"]
            for keyword in keywords:
                if keyword.lower() in first_user_message.lower():
                    return f"{keyword.title()} Support"
            return "Mental Health Support"

    def __init_crisis_data(self):
        """Initialize crisis detection data"""
        # Crisis keywords that trigger immediate intervention
        self.crisis_keywords = [
            "suicide", "kill myself", "end my life", "hurt myself",
            "self-harm", "cutting", "overdose", "worthless",
            "hopeless", "can't go on", "better off dead",
            "want to die", "planning to hurt", "no way out"
        ]
        
        # Severity indicators
        self.high_risk_patterns = [
            r"(?i)\b(severely? depressed|extremely anxious|panic attack)\b",
            r"(?i)\b(can't function|stopped eating|can't sleep for days)\b",
            r"(?i)\b(isolat.*completely|haven't left room)\b",
            r"(?i)\b(thoughts? of harm|thinking about death)\b"
        ]
        
        self.system_prompt = """You are EmotiCare AI, a compassionate mental health support assistant specifically designed for college students in India. Your role is to provide immediate emotional support, coping strategies, and guidance while being culturally sensitive.

CORE PRINCIPLES:
1. Always prioritize student safety and well-being
2. Be empathetic, non-judgmental, and culturally aware
3. Provide practical, evidence-based coping strategies
4. Recognize when professional intervention is needed
5. Respect Indian cultural contexts and values

CAPABILITIES:
- Provide emotional support and active listening
- Suggest breathing exercises, mindfulness techniques
- Offer stress management strategies for academic pressure
- Help with anxiety, depression, and relationship issues
- Provide study-life balance guidance
- Recognize crisis situations and escalate appropriately

LIMITATIONS:
- You are NOT a replacement for professional therapy
- You cannot diagnose mental health conditions
- You cannot prescribe medications
- For crisis situations, always recommend immediate professional help

RESPONSE GUIDELINES:
1. Start with empathy and validation
2. Ask clarifying questions to understand better
3. Provide 2-3 specific, actionable coping strategies
4. Suggest relevant resources when appropriate
5. End with supportive encouragement
6. If crisis indicators detected, prioritize safety and professional referral

CULTURAL CONSIDERATIONS:
- Understand family pressure and expectations in Indian context
- Be sensitive to stigma around mental health
- Respect religious and cultural beliefs
- Consider socio-economic factors affecting students

Remember: You're here to provide immediate support while connecting students to appropriate professional resources when needed."""

    def analyze_crisis_indicators(self, message: str) -> Tuple[bool, List[str], str]:
        """
        Analyze message for crisis indicators
        Returns: (requires_intervention, crisis_indicators, risk_level)
        """
        message_lower = message.lower()
        crisis_indicators = []
        requires_intervention = False
        risk_level = "low"
        
        # Check for direct crisis keywords
        for keyword in self.crisis_keywords:
            if keyword in message_lower:
                crisis_indicators.append(f"Crisis keyword: {keyword}")
                requires_intervention = True
                risk_level = "critical"
        
        # Check for high-risk patterns
        for pattern in self.high_risk_patterns:
            if re.search(pattern, message):
                crisis_indicators.append(f"High-risk pattern detected")
                if risk_level != "critical":
                    risk_level = "high"
        
        # Additional risk factors
        if any(phrase in message_lower for phrase in [
            "can't handle", "too much pressure", "failing everything",
            "parents will kill me", "disappointed everyone", "no friends"
        ]):
            crisis_indicators.append("Emotional distress indicators")
            if risk_level == "low":
                risk_level = "medium"
        
        return requires_intervention, crisis_indicators, risk_level

    def get_emotional_state(self, message: str) -> EmotionalState:
        """Determine emotional state from message"""
        message_lower = message.lower()
        
        if any(word in message_lower for word in [
            "suicide", "hopeless", "can't go on", "worthless", "devastated"
        ]):
            return EmotionalState.VERY_DISTRESSED
        
        elif any(word in message_lower for word in [
            "anxious", "stressed", "worried", "depressed", "overwhelmed", "scared"
        ]):
            return EmotionalState.DISTRESSED
        
        elif any(word in message_lower for word in [
            "okay", "fine", "normal", "alright", "managing"
        ]):
            return EmotionalState.NEUTRAL
        
        elif any(word in message_lower for word in [
            "calm", "peaceful", "relaxed", "better", "stable"
        ]):
            return EmotionalState.CALM
        
        elif any(word in message_lower for word in [
            "happy", "excited", "great", "wonderful", "amazing", "good"
        ]):
            return EmotionalState.POSITIVE
        
        return EmotionalState.NEUTRAL

    async def generate_response(
        self, 
        message: str, 
        chat_history: List[ChatMessage] = None,
        user_context: Dict[str, Any] = None,
        session_id: str = None
    ) -> ChatResponse:
        """Generate AI response using React Agent with tools"""
        try:
            # Use session_id if provided, otherwise generate one
            if not session_id:
                session_id = f"chat_{datetime.now().isoformat()}"
            
            # Get or create conversation history for this session
            if session_id not in self.conversations:
                self.conversations[session_id] = []
            
            # Add current user input to history
            self.conversations[session_id].append({"role": "user", "content": message})
            
            # Build enhanced input with context
            enhanced_input = self._build_enhanced_input(
                user_input=message,
                conversation_history=self.conversations[session_id],
                user_profile=user_context,
                context_type="chat"
            )
            
            # Get React agent
            agent_executor = await self.get_react_agent()
            
            # Prepare messages for React Agent
            messages = []
            
            # Add conversation history as messages
            for msg in self.conversations[session_id][:-1]:  # Exclude current message
                if msg["role"] == "user":
                    messages.append({"role": "user", "content": msg["content"]})
                else:
                    messages.append({"role": "assistant", "content": msg["content"]})
            
            # Add current message with system context if first message
            if not messages:
                current_message = f"SYSTEM CONTEXT: {self.system_message.content}\n\nUSER MESSAGE: {enhanced_input}"
            else:
                current_message = enhanced_input
            
            messages.append({"role": "user", "content": current_message})
            
            # Configure agent for this session
            config = {"configurable": {"thread_id": session_id}}
            
            logger.info(f"Processing message for session {session_id}")
            logger.info(f"Total conversation history: {len(self.conversations[session_id])} messages")
            
            # Run React Agent
            result = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: agent_executor.invoke(
                    {"messages": messages},
                    config=config
                )
            )
            
            logger.info(f"Agent execution completed. Result contains {len(result.get('messages', []))} messages")
            
            # Extract response from agent result
            if "messages" in result and result["messages"]:
                logger.info("Extracting response from agent messages")
                # Get the last AI message
                ai_messages = [msg for msg in result["messages"] if hasattr(msg, 'content') and getattr(msg, 'type', None) == 'ai']
                if ai_messages:
                    ai_response = ai_messages[-1].content
                    logger.info(f"Found AI message response: {ai_response[:100]}...")
                else:
                    # Fallback to last message content
                    ai_response = result["messages"][-1].content if hasattr(result["messages"][-1], 'content') else str(result["messages"][-1])
                    logger.info(f"Using fallback response: {ai_response[:100]}...")
            else:
                ai_response = "I'm here to support you. Could you tell me more about how you're feeling?"
                logger.info("Using default fallback response")
            
            # Add assistant response to our conversation history
            self.conversations[session_id].append({"role": "assistant", "content": ai_response})
            logger.info(f"Response added to conversation. Total messages now: {len(self.conversations[session_id])}")
            
            # Analyze for crisis indicators
            requires_intervention, crisis_indicators, risk_level = self.analyze_crisis_indicators(message)
            
            # Get relevant resources and next steps
            resources = self._get_relevant_resources(message, EmotionalState.NEUTRAL)  # Use default state
            next_steps = self._get_next_steps(risk_level, EmotionalState.NEUTRAL)
            
            return ChatResponse(
                message=ai_response,
                requires_intervention=requires_intervention,
                suggested_resources=resources,
                emotional_support_level="low" if not requires_intervention else "high",
                next_steps=next_steps
            )
            
        except Exception as e:
            logger.error(f"Error generating response: {e}")
            # Fallback response
            return ChatResponse(
                message="I'm here to support you. Could you tell me more about how you're feeling?",
                requires_intervention=False,
                suggested_resources=[],
                emotional_support_level="low",
                next_steps=["Share more about your feelings", "Consider speaking with a counselor"]
            )

    def _build_enhanced_input(
        self, 
        user_input: str, 
        conversation_history: List[Dict[str, str]], 
        user_profile: Dict[str, Any] = None,
        context_type: str = "chat"
    ) -> str:
        """Build enhanced input with complete conversation context"""
        
        # Start with context information
        context_parts = []
        
        # Add user profile context
        if user_profile:
            profile_info = []
            if user_profile.get("role"):
                profile_info.append(f"Role: {user_profile['role']}")
            if user_profile.get("department"):
                profile_info.append(f"Department: {user_profile['department']}")
            if user_profile.get("year_of_study"):
                profile_info.append(f"Year: {user_profile['year_of_study']}")
            
            if profile_info:
                context_parts.append(f"[User Profile: {', '.join(profile_info)}]")
        
        # Add conversation type context
        if context_type == "voice":
            context_parts.append("[Voice conversation - keep response under 100 words, conversational tone]")
        
        # Build complete conversation history
        if len(conversation_history) > 1:  # More than just current message
            history_parts = []
            # Include ALL conversation history (not limited to last few)
            for msg in conversation_history[:-1]:  # Exclude current message as it's added separately
                role = "Human" if msg["role"] == "user" else "Assistant"
                history_parts.append(f"{role}: {msg['content']}")
            
            if history_parts:
                context_parts.append(f"Previous conversation:\n{chr(10).join(history_parts)}")
        
        # Combine context and current input
        if context_parts:
            enhanced_input = f"{chr(10).join(context_parts)}\n\nCurrent message: {user_input}"
        else:
            enhanced_input = user_input
        
        return enhanced_input

    async def analyze_root_causes(
        self, 
        current_message: str, 
        chat_history: List[ChatMessage]
    ) -> Optional[Dict[str, Any]]:
        """Analyze conversation to identify potential root causes of anxiety/depression"""
        try:
            # Build conversation context for analysis
            conversation_text = "\n".join([
                f"User: {msg.content}" if msg.role == "user" else f"Assistant: {msg.content}"
                for msg in chat_history[-10:]  # Last 10 messages
            ])
            conversation_text += f"\nUser: {current_message}"
            
            analysis_prompt = f"""
You are a mental health AI analyst. Analyze this conversation to identify potential root causes of the user's anxiety, depression, or emotional distress. Focus on recurring themes, triggers, and underlying issues.

CONVERSATION:
{conversation_text}

Provide analysis in the following JSON format:
{{
    "primary_concerns": ["list of main emotional/mental health concerns"],
    "potential_triggers": ["specific situations, events, or thoughts that seem to trigger distress"],
    "root_causes": ["deeper underlying causes that may be contributing to the mental health issues"],
    "patterns": ["recurring behavioral or thought patterns"],
    "strengths": ["positive coping mechanisms or strengths shown by the user"],
    "recommendations": ["specific therapeutic approaches or interventions that might help"],
    "urgency_level": "low/medium/high",
    "counselor_notes": "Professional insights for counselors about this student's case"
}}

Focus on:
- Academic pressures and perfectionism
- Family expectations and cultural pressures
- Social isolation and relationship issues
- Financial stress
- Career anxiety and future uncertainty
- Self-esteem and identity issues
- Trauma or significant life events

Be compassionate, professional, and evidence-based in your analysis.
"""
            
            messages = [
                SystemMessage(content="You are a professional mental health analyst trained in identifying root causes of anxiety and depression in college students."),
                HumanMessage(content=analysis_prompt)
            ]
            
            response = await self.analysis_llm.ainvoke(messages)
            
            # Parse JSON response
            try:
                insights = json.loads(response.content)
                insights["analysis_timestamp"] = datetime.utcnow().isoformat()
                return insights
            except json.JSONDecodeError:
                # If JSON parsing fails, create a simple structure
                return {
                    "primary_concerns": ["Emotional distress detected"],
                    "potential_triggers": ["Multiple stressors identified"],
                    "root_causes": ["Analysis in progress"],
                    "patterns": ["Ongoing assessment"],
                    "strengths": ["Seeking help and support"],
                    "recommendations": ["Professional counseling recommended"],
                    "urgency_level": "medium",
                    "counselor_notes": "Detailed analysis available - student engaging in mental health support",
                    "analysis_timestamp": datetime.utcnow().isoformat()
                }
                
        except Exception as e:
            return None

    async def store_emotional_insights(
        self, 
        user_id: str, 
        insights: Dict[str, Any], 
        risk_level: str
    ):
        """Store emotional insights and root cause analysis in database"""
        try:
            db = await get_database()
            
            insight_document = {
                "user_id": user_id,
                "insights": insights,
                "risk_level": risk_level,
                "created_at": datetime.utcnow(),
                "type": "root_cause_analysis",
                "status": "active"
            }
            
            # Store in emotional_insights collection
            await db.emotional_insights.insert_one(insight_document)
            
            # Update user's mental health profile
            await db.users.update_one(
                {"_id": user_id},
                {
                    "$set": {
                        "latest_emotional_analysis": insights,
                        "last_analysis_date": datetime.utcnow(),
                        "current_risk_level": risk_level
                    }
                }
            )
            
            # If high risk, create counselor alert with insights
            if risk_level in ["high", "critical"]:
                await self._create_counselor_insight_alert(user_id, insights, risk_level)
                
        except Exception as e:
            pass  # Don't fail chat response if storage fails

    async def _create_counselor_insight_alert(
        self, 
        user_id: str, 
        insights: Dict[str, Any], 
        risk_level: str
    ):
        """Create alert for counselors with detailed insights"""
        try:
            counselor_summary = f"""
STUDENT EMOTIONAL ANALYSIS ALERT

Risk Level: {risk_level.upper()}
Analysis Date: {datetime.utcnow().strftime('%Y-%m-%d %H:%M')}

PRIMARY CONCERNS:
{', '.join(insights.get('primary_concerns', []))}

POTENTIAL TRIGGERS:
{', '.join(insights.get('potential_triggers', []))}

ROOT CAUSES IDENTIFIED:
{', '.join(insights.get('root_causes', []))}

BEHAVIORAL PATTERNS:
{', '.join(insights.get('patterns', []))}

RECOMMENDED INTERVENTIONS:
{', '.join(insights.get('recommendations', []))}

COUNSELOR NOTES:
{insights.get('counselor_notes', 'Standard counseling protocols recommended')}

STUDENT STRENGTHS:
{', '.join(insights.get('strengths', ['Seeking help through EmotiCare system']))}

This analysis is based on AI processing of chat conversations and should be used as supplementary information alongside professional clinical assessment.
"""
            
            await notification_service.send_crisis_alert(
                user_id=user_id,
                crisis_type="emotional_analysis_alert",
                severity=risk_level,
                details={
                    "analysis_summary": counselor_summary,
                    "insights": insights,
                    "recommendation": "Schedule counseling session to discuss identified concerns"
                }
            )
            
        except Exception as e:
            pass

    async def get_user_emotional_timeline(self, user_id: str) -> List[Dict[str, Any]]:
        """Get emotional insights timeline for a user"""
        try:
            db = await get_database()
            
            timeline = []
            cursor = db.emotional_insights.find({
                "user_id": user_id
            }).sort("created_at", -1).limit(10)
            
            async for insight in cursor:
                timeline.append({
                    "date": insight["created_at"],
                    "risk_level": insight["risk_level"],
                    "primary_concerns": insight["insights"].get("primary_concerns", []),
                    "triggers": insight["insights"].get("potential_triggers", []),
                    "improvements": insight["insights"].get("strengths", [])
                })
            
            return timeline
            
        except Exception as e:
            return []

    async def get_counselor_insights_summary(self, user_id: str) -> Dict[str, Any]:
        """Get comprehensive insights summary for counselors"""
        try:
            db = await get_database()
            
            # Get latest analysis
            latest_insight = await db.emotional_insights.find_one({
                "user_id": user_id
            }, sort=[("created_at", -1)])
            
            if not latest_insight:
                return {"message": "No emotional analysis available yet"}
            
            # Get user's chat session count and assessment history
            chat_sessions = await db.chat_sessions.count_documents({"user_id": user_id})
            assessments = []
            async for assessment in db.assessments.find({
                "user_id": user_id
            }).sort("created_at", -1).limit(5):
                assessments.append({
                    "type": assessment["assessment_type"],
                    "score": assessment["score"],
                    "risk_level": assessment["risk_level"],
                    "date": assessment["created_at"]
                })
            
            return {
                "latest_analysis": latest_insight["insights"],
                "analysis_date": latest_insight["created_at"],
                "current_risk_level": latest_insight["risk_level"],
                "engagement_stats": {
                    "chat_sessions": chat_sessions,
                    "recent_assessments": assessments
                },
                "recommendations": latest_insight["insights"].get("recommendations", []),
                "counselor_notes": latest_insight["insights"].get("counselor_notes", "")
            }
            
        except Exception as e:
            return {"error": "Failed to retrieve insights summary"}

    def _get_relevant_resources(self, message: str, emotional_state: EmotionalState) -> List[str]:
        """Get relevant resource suggestions based on message content"""
        resources = []
        message_lower = message.lower()
        
        if any(word in message_lower for word in ["anxious", "anxiety", "panic", "nervous"]):
            resources.extend(["anxiety_coping_techniques", "breathing_exercises", "grounding_techniques"])
        
        if any(word in message_lower for word in ["depressed", "depression", "sad", "hopeless"]):
            resources.extend(["depression_support", "mood_lifting_activities", "self_care_guide"])
        
        if any(word in message_lower for word in ["stress", "stressed", "pressure", "overwhelmed"]):
            resources.extend(["stress_management", "time_management", "study_techniques"])
        
        if any(word in message_lower for word in ["sleep", "insomnia", "tired", "exhausted"]):
            resources.extend(["sleep_hygiene", "relaxation_techniques"])
        
        if any(word in message_lower for word in ["exam", "study", "academic", "grades"]):
            resources.extend(["study_skills", "exam_anxiety_help", "academic_support"])
        
        if any(word in message_lower for word in ["family", "parents", "home", "relationship"]):
            resources.extend(["family_communication", "relationship_help", "boundary_setting"])
        
        # Add mindfulness for all emotional states except positive
        if emotional_state != EmotionalState.POSITIVE:
            resources.append("mindfulness_meditation")
        
        return list(set(resources))  # Remove duplicates

    def _get_next_steps(self, risk_level: str, emotional_state: EmotionalState) -> List[str]:
        """Get recommended next steps based on risk level and emotional state"""
        if risk_level == "critical":
            return [
                "Contact emergency services (112) if in immediate danger",
                "Reach out to a trusted adult or family member",
                "Visit campus counseling center or nearest hospital",
                "Use crisis helpline: 91-9152987821"
            ]
        
        elif risk_level == "high":
            return [
                "Schedule appointment with campus counselor within 24-48 hours",
                "Talk to a trusted friend, family member, or mentor",
                "Practice immediate coping techniques",
                "Monitor your emotional state closely"
            ]
        
        elif risk_level == "medium":
            return [
                "Consider scheduling counseling appointment this week",
                "Try suggested coping strategies",
                "Maintain regular self-care routine",
                "Check in with supportive friends or family"
            ]
        
        else:  # low risk
            return [
                "Practice suggested wellness techniques",
                "Maintain good self-care habits",
                "Stay connected with support network",
                "Consider preventive mental health resources"
            ]

# Global instance
mental_health_chat = MentalHealthChatService()