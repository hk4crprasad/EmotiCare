import asyncio
import logging
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
import json

from langchain_openai import AzureChatOpenAI
from langchain_core.tools import tool
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
from langgraph.prebuilt import create_react_agent
from langgraph.checkpoint.memory import MemorySaver
from langchain_mcp_adapters.client import MultiServerMCPClient
from app.config import settings
from app.database import get_database

logger = logging.getLogger(__name__)

# Mental Health Tools for React Agent
@tool
def get_breathing_exercise() -> str:
    """Provides a simple breathing exercise for anxiety and stress relief"""
    return """Try this 4-7-8 breathing technique:
1. Inhale through your nose for 4 counts
2. Hold your breath for 7 counts  
3. Exhale through your mouth for 8 counts
4. Repeat 3-4 times
This activates your parasympathetic nervous system and promotes calm."""

@tool
def get_grounding_technique() -> str:
    """Provides a 5-4-3-2-1 grounding technique for anxiety and panic"""
    return """Use the 5-4-3-2-1 grounding technique:
- 5 things you can SEE around you
- 4 things you can TOUCH 
- 3 things you can HEAR
- 2 things you can SMELL
- 1 thing you can TASTE
This helps bring you back to the present moment and reduces anxiety."""

@tool
def get_study_tips() -> str:
    """Provides evidence-based study tips for academic stress"""
    return """Effective study strategies:
1. Pomodoro Technique: 25min study + 5min break
2. Active recall: Test yourself instead of re-reading
3. Spaced repetition: Review material at increasing intervals
4. Break large tasks into smaller, manageable chunks
5. Create a consistent study schedule
6. Find a quiet, dedicated study space"""

@tool
def assess_crisis_risk(user_message: str) -> str:
    """Assesses if the user needs immediate crisis intervention"""
    crisis_keywords = [
        "suicide", "kill myself", "end it all", "can't go on", 
        "self-harm", "hurt myself", "no point", "better off dead"
    ]
    
    if any(keyword in user_message.lower() for keyword in crisis_keywords):
        return """CRISIS ALERT: Please reach out for immediate support:
• National Suicide Prevention Lifeline: 988
• Crisis Text Line: Text HOME to 741741
• Emergency Services: 911
• Campus Crisis Hotline: Available 24/7
You are not alone, and help is available right now."""
    
    return "No immediate crisis indicators detected."

@tool
def check_appointment_availability() -> str:
    """Checks if counseling appointments are available"""
    # For now, return a simple availability message
    # In production, this would check actual database
    return "Good news! We have counselors available. You can book an appointment through the platform or contact us directly for urgent needs."
async def setup_mcp_client():
    client = MultiServerMCPClient({
        "math": {
            "transport": "sse",
            "url": "http://localhost:8001/sse"
        },
    })
    mcp_tools = await client.get_tools()  # await here
    return mcp_tools

class AIService:
    """Enhanced AI service with LangChain and tool calling for mental health support"""
    
    @classmethod
    async def create(cls):
        """Async factory method to create AIService with MCP tools"""
        try:
            mcp_tools = await setup_mcp_client()
        except Exception as e:
            logger.warning(f"Failed to setup MCP client: {e}. Continuing with base tools only.")
            mcp_tools = []
        
        # Create instance bypassing __init__
        self = cls.__new__(cls)
        
        # Initialize Azure OpenAI with LangChain
        self.llm = AzureChatOpenAI(
            azure_deployment=settings.AZURE_OPENAI_DEPLOYMENT,
            azure_endpoint=settings.AZURE_OPENAI_ENDPOINT,
            api_key=settings.AZURE_OPENAI_API_KEY,
            api_version=settings.AZURE_OPENAI_API_VERSION,
            temperature=0.7,
            max_tokens=500
        )
        
        # Define mental health tools synchronously
        base_tools = [
            get_breathing_exercise,
            get_grounding_technique,
            get_study_tips,
            assess_crisis_risk,
            check_appointment_availability
        ]
        self.tools = base_tools + mcp_tools
        
        # Create React Agent with memory and enable global verbose/debug logging
        from langchain.globals import set_verbose, set_debug
        
        # Enable verbose logging for agent execution (shows important events)
        set_verbose(True)
        
        # Optionally enable debug mode for ALL events (uncomment for maximum detail)
        # set_debug(True)
        
        memory = MemorySaver()
        self.agent_executor = create_react_agent(
            self.llm, 
            self.tools, 
            checkpointer=memory
        )
        
        # Store conversations by session_id (complete history)
        self.conversations = {}
        
        # System message for mental health support
        self.system_message = SystemMessage(content="""You are a compassionate AI mental health assistant for EmotiCare, a university counseling platform.

CORE PRINCIPLES:
1. EMPATHY: Always acknowledge and validate feelings
2. SAFETY: Prioritize user safety and crisis intervention  
3. SUPPORT: Provide practical coping strategies
4. BOUNDARIES: Never diagnose or replace professional therapy
5. EVIDENCE-BASED: Use proven techniques and tools
6. CONTINUITY: Remember and reference previous parts of our conversation

RESPONSE GUIDELINES:
- Use warm, understanding language
- Keep responses concise (under 150 words for voice, longer for text if needed)
- Ask thoughtful follow-up questions
- ALWAYS use available tools when appropriate to provide specific techniques
- Encourage professional help when needed
- Be culturally sensitive and inclusive

TOOL USAGE INSTRUCTIONS:
- When user mentions anxiety, stress, or panic: USE get_breathing_exercise or get_grounding_technique tools
- When user asks about studying or academic stress: USE get_study_tips tool
- When user mentions harm, suicide, or crisis words: IMMEDIATELY USE assess_crisis_risk tool
- When user asks about counseling appointments: USE check_appointment_availability tool

You MUST use the appropriate tools to provide specific, helpful techniques rather than general advice.

If crisis indicators are detected, IMMEDIATELY use the assess_crisis_risk tool and prioritize safety.""")
        
        logger.info("AI Service initialized with LangGraph React Agent and mental health tools")
        logger.info(f"Available tools: {[tool.name for tool in self.tools]}")
        logger.info(f"Total tools count: {len(self.tools)}")
        for tool in self.tools:
            logger.info(f"Tool: {tool.name} - {tool.description}")
        logger.info("Verbose mode enabled for detailed agent execution logging")
        
        return self

    def __init__(self):
        """Private init - use AIService.create() instead for proper async initialization"""
        raise RuntimeError("Use AIService.create() for proper async initialization with MCP tools")
    
    async def generate_mental_health_response(
        self,
        user_input: str,
        conversation_history: List[Dict[str, str]] = None,
        user_profile: Dict[str, Any] = None,
        context_type: str = "chat",
        session_id: str = "default"
    ) -> str:
        """Generate empathetic mental health response using LangGraph React Agent with full history"""
        try:
            # Get or create conversation history for this session
            if session_id not in self.conversations:
                self.conversations[session_id] = []
            
            # Add current user input to history
            self.conversations[session_id].append({"role": "user", "content": user_input})
            
            # Build enhanced input with complete conversation context
            enhanced_input = self._build_enhanced_input(
                user_input=user_input,
                conversation_history=self.conversations[session_id],
                user_profile=user_profile,
                context_type=context_type
            )
            
            # Prepare messages for React Agent
            messages = []
            
            # Add system context as part of the first message
            system_context = self.system_message.content
            if context_type == "voice":
                system_context += "\n\nIMPORTANT: Keep responses under 100 words for voice interaction."
            
            # Add conversation history as messages
            for msg in self.conversations[session_id][:-1]:  # Exclude current message
                if msg["role"] == "user":
                    messages.append({"role": "user", "content": msg["content"]})
                else:
                    messages.append({"role": "assistant", "content": msg["content"]})
            
            # Add current message with system context if first message
            if not messages:
                current_message = f"SYSTEM CONTEXT: {system_context}\n\nUSER MESSAGE: {enhanced_input}"
            else:
                current_message = enhanced_input
            
            messages.append({"role": "user", "content": current_message})
            
            # Configure agent for this session
            config = {"configurable": {"thread_id": session_id}}
            
            logger.info(f"Processing message for session {session_id}")
            logger.info(f"Total conversation history: {len(self.conversations[session_id])} messages")
            logger.info(f"Context type: {context_type}")
            
            # Run React Agent
            result = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: self.agent_executor.invoke(
                    {"messages": messages},
                    config=config
                )
            )
            
            logger.info(f"Agent execution completed. Result contains {len(result.get('messages', []))} messages")
            
            # Extract response from agent result
            if "messages" in result and result["messages"]:
                logger.info("Extracting response from agent messages")
                # Get the last AI message
                ai_messages = [msg for msg in result["messages"] if hasattr(msg, 'content') and getattr(msg, 'type', None) == 'ai']
                if ai_messages:
                    response = ai_messages[-1].content
                    logger.info(f"Found AI message response: {response[:100]}...")
                else:
                    # Fallback to last message content
                    response = result["messages"][-1].content if hasattr(result["messages"][-1], 'content') else str(result["messages"][-1])
                    logger.info(f"Using fallback response: {response[:100]}...")
            else:
                response = "I'm here to support you. Could you tell me more about how you're feeling?"
                logger.info("Using default fallback response")
            
            # Add assistant response to our conversation history
            self.conversations[session_id].append({"role": "assistant", "content": response})
            logger.info(f"Response added to conversation. Total messages now: {len(self.conversations[session_id])}")
            
            return response
            
        except Exception as e:
            logger.error(f"Error with React Agent: {e}")
            return self._get_fallback_response(user_input)
    
    def _build_enhanced_input(
        self, 
        user_input: str, 
        conversation_history: List[Dict[str, str]], 
        user_profile: Dict[str, Any] = None,
        context_type: str = "chat"
    ) -> str:
        """Build enhanced input with complete conversation context"""
        
        # Start with context information
        context_parts = []
        
        # Add user profile context
        if user_profile:
            profile_info = []
            if user_profile.get("role"):
                profile_info.append(f"Role: {user_profile['role']}")
            if user_profile.get("department"):
                profile_info.append(f"Department: {user_profile['department']}")
            if user_profile.get("year_of_study"):
                profile_info.append(f"Year: {user_profile['year_of_study']}")
            
            if profile_info:
                context_parts.append(f"[User Profile: {', '.join(profile_info)}]")
        
        # Add conversation type context
        if context_type == "voice":
            context_parts.append("[Voice conversation - keep response under 100 words, conversational tone]")
        
        # Build complete conversation history
        if len(conversation_history) > 1:  # More than just current message
            history_parts = []
            # Include ALL conversation history (not limited to last few)
            for msg in conversation_history[:-1]:  # Exclude current message as it's added separately
                role = "Human" if msg["role"] == "user" else "Assistant"
                history_parts.append(f"{role}: {msg['content']}")
            
            if history_parts:
                context_parts.append(f"Previous conversation:\n{chr(10).join(history_parts)}")
        
        # Combine context and current input
        if context_parts:
            enhanced_input = f"{chr(10).join(context_parts)}\n\nCurrent message: {user_input}"
        else:
            enhanced_input = user_input
        
        return enhanced_input
    
    def _get_fallback_response(self, user_input: str) -> str:
        """Provide a safe fallback response if the agent fails"""
        crisis_keywords = ["suicide", "kill", "harm", "die", "end it"]
        
        if any(keyword in user_input.lower() for keyword in crisis_keywords):
            return """I'm very concerned about you right now. Please reach out for immediate support:
• National Suicide Prevention Lifeline: 988
• Crisis Text Line: Text HOME to 741741
• Emergency Services: 911
You are not alone, and help is available."""
        
        return """I understand you're reaching out for support, and I want to help. Sometimes I need a moment to process - could you tell me a bit more about what you're experiencing right now? I'm here to listen and support you."""

    async def generate_voice_response(
        self,
        user_input: str,
        user_profile: Dict[str, Any] = None,
        session_id: str = "voice_default"
    ) -> str:
        """Generate optimized response for voice interaction with complete history"""
        return await self.generate_mental_health_response(
            user_input=user_input,
            user_profile=user_profile,
            context_type="voice",
            session_id=session_id
        )
    
    async def get_conversation_summary(self, session_id: str) -> str:
        """Get a summary of the conversation for context"""
        if session_id not in self.conversations or not self.conversations[session_id]:
            return "No previous conversation history."
        
        history = self.conversations[session_id]
        if len(history) <= 2:  # Just current exchange
            return "Beginning of conversation."
        
        # Get last 10 messages for summary (5 exchanges)
        recent_messages = history[-10:] if len(history) > 10 else history[:-2]  # Exclude current exchange
        
        summary_parts = []
        for i in range(0, len(recent_messages), 2):
            if i + 1 < len(recent_messages):
                user_msg = recent_messages[i].get("content", "")[:100]
                assistant_msg = recent_messages[i + 1].get("content", "")[:100]
                summary_parts.append(f"User: {user_msg}...")
                summary_parts.append(f"Assistant: {assistant_msg}...")
        
        return "\n".join(summary_parts)
    
    def get_conversation_length(self, session_id: str) -> int:
        """Get the number of messages in a conversation session"""
        if session_id not in self.conversations:
            return 0
        return len(self.conversations[session_id])
    
    def get_full_conversation_history(self, session_id: str) -> List[Dict[str, str]]:
        """Get the complete conversation history for a session"""
        return self.conversations.get(session_id, [])
    
    async def clear_conversation(self, session_id: str):
        """Clear conversation history for a session"""
        if session_id in self.conversations:
            del self.conversations[session_id]
    
    def get_tools_info(self) -> List[Dict[str, str]]:
        """Get information about available tools"""
        return [
            {
                "name": "get_breathing_exercise",
                "description": "Provides guided breathing exercises for anxiety and stress relief"
            },
            {
                "name": "get_grounding_technique", 
                "description": "Offers 5-4-3-2-1 grounding technique for anxiety and panic"
            },
            {
                "name": "get_study_tips",
                "description": "Shares evidence-based study strategies for academic stress"
            },
            {
                "name": "assess_crisis_risk",
                "description": "Evaluates messages for crisis indicators and provides emergency resources"
            },
            {
                "name": "check_appointment_availability",
                "description": "Checks counselor availability for appointments"
            }
        ]

# Global AI service instance - initialized async
ai_service = None

async def get_ai_service():
    """Get or create the global AI service instance"""
    global ai_service
    if ai_service is None:
        ai_service = await AIService.create()
    return ai_service