import React, { useState } from 'react';
import { Header } from './components/Header';
import { LandingPage } from './components/LandingPage';
import { ChatInterface } from './components/ChatInterface';
import { BookingSystem } from './components/BookingSystem';
import { ResourceHub } from './components/ResourceHub';
import { PeerSupport } from './components/PeerSupport';
import { AdminDashboard } from './components/AdminDashboard';
import { AuthPage } from './components/AuthPage';

export type Page = 'home' | 'chat' | 'booking' | 'resources' | 'forum' | 'admin' | 'auth';

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [userRole, setUserRole] = useState<'student' | 'counselor' | 'admin'>('student');

  const handleLogin = (role: 'student' | 'counselor' | 'admin') => {
    setIsAuthenticated(true);
    setUserRole(role);
    setCurrentPage('home');
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setCurrentPage('home');
  };

  const renderPage = () => {
    if (!isAuthenticated && currentPage !== 'home') {
      return <AuthPage onLogin={handleLogin} />;
    }

    switch (currentPage) {
      case 'home':
        return <LandingPage onNavigate={setCurrentPage} isAuthenticated={isAuthenticated} />;
      case 'chat':
        return <ChatInterface />;
      case 'booking':
        return <BookingSystem />;
      case 'resources':
        return <ResourceHub />;
      case 'forum':
        return <PeerSupport />;
      case 'admin':
        return userRole === 'admin' ? <AdminDashboard /> : <LandingPage onNavigate={setCurrentPage} isAuthenticated={isAuthenticated} />;
      case 'auth':
        return <AuthPage onLogin={handleLogin} />;
      default:
        return <LandingPage onNavigate={setCurrentPage} isAuthenticated={isAuthenticated} />;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header 
        currentPage={currentPage} 
        onNavigate={setCurrentPage}
        isAuthenticated={isAuthenticated}
        userRole={userRole}
        onLogout={handleLogout}
      />
      <main>
        {renderPage()}
      </main>
    </div>
  );
}