import React from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { MessageCircle, Calendar, BookOpen, Users, Shield, Clock, Heart, Brain, Zap } from 'lucide-react';

interface LandingPageProps {
  onNavigate: (page: any) => void;
  isAuthenticated: boolean;
}

export function LandingPage({ onNavigate, isAuthenticated }: LandingPageProps) {
  const features = [
    {
      icon: MessageCircle,
      title: 'AI-Guided Support',
      description: 'Get instant help through our intelligent chatbot that provides coping strategies and crisis support.',
      action: () => onNavigate('chat'),
      color: 'bg-blue-50 text-blue-600'
    },
    {
      icon: Calendar,
      title: 'Confidential Booking',
      description: 'Schedule appointments with on-campus counselors or access mental health helplines privately.',
      action: () => onNavigate('booking'),
      color: 'bg-green-50 text-green-600'
    },
    {
      icon: BookOpen,
      title: 'Resource Hub',
      description: 'Access videos, relaxation audio, and wellness guides available in regional languages.',
      action: () => onNavigate('resources'),
      color: 'bg-purple-50 text-purple-600'
    },
    {
      icon: Users,
      title: 'Peer Support',
      description: 'Connect with other students in moderated forums with trained student volunteer support.',
      action: () => onNavigate('forum'),
      color: 'bg-orange-50 text-orange-600'
    }
  ];

  const stats = [
    { number: '24/7', label: 'AI Support Available' },
    { number: '100%', label: 'Confidential & Secure' },
    { number: '15+', label: 'Regional Languages' },
    { number: '500+', label: 'Students Helped' }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-50 to-purple-50 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <Badge className="mb-4 bg-blue-100 text-blue-800">
                Mental Health Support for Students
              </Badge>
              <h1 className="text-4xl lg:text-5xl mb-6 text-gray-900">
                Your Mental Wellness Journey Starts Here
              </h1>
              <p className="text-xl text-gray-600 mb-8">
                A comprehensive digital platform providing stigma-free psychological support, 
                early intervention tools, and peer connections tailored for college students.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                {isAuthenticated ? (
                  <Button size="lg" onClick={() => onNavigate('chat')} className="bg-primary hover:bg-primary/90">
                    <MessageCircle className="mr-2 h-5 w-5" />
                    Get Support Now
                  </Button>
                ) : (
                  <Button size="lg" onClick={() => onNavigate('auth')} className="bg-primary hover:bg-primary/90">
                    Get Started
                  </Button>
                )}
                <Button size="lg" variant="outline" onClick={() => onNavigate('resources')}>
                  <BookOpen className="mr-2 h-5 w-5" />
                  Explore Resources
                </Button>
              </div>
            </div>
            <div className="relative">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1642287342121-8857cd9d1f5f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2xsZWdlJTIwc3R1ZGVudHMlMjBtZW50YWwlMjBoZWFsdGglMjBzdXBwb3J0fGVufDF8fHx8MTc1ODExNzAwOHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Students supporting each other"
                className="rounded-2xl shadow-2xl w-full h-96 object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-3xl font-bold text-primary mb-2">{stat.number}</div>
                <div className="text-gray-600">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl mb-4">Complete Mental Health Support System</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Our platform integrates multiple support mechanisms to provide comprehensive, 
              culturally-sensitive mental health care for college students.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Card key={index} className="p-6 hover:shadow-lg transition-shadow cursor-pointer" onClick={feature.action}>
                  <div className={`w-12 h-12 rounded-lg ${feature.color} flex items-center justify-center mb-4`}>
                    <Icon className="h-6 w-6" />
                  </div>
                  <h3 className="text-xl mb-3">{feature.title}</h3>
                  <p className="text-gray-600 mb-4">{feature.description}</p>
                  <Button variant="ghost" className="p-0 h-auto">
                    Learn More →
                  </Button>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-3xl lg:text-4xl mb-6">Why MindWell?</h2>
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="bg-green-100 p-2 rounded-lg">
                    <Shield className="h-6 w-6 text-green-600" />
                  </div>
                  <div>
                    <h3 className="text-lg mb-2">100% Confidential</h3>
                    <p className="text-gray-600">Your privacy is our priority. All interactions are encrypted and anonymous.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="bg-blue-100 p-2 rounded-lg">
                    <Clock className="h-6 w-6 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="text-lg mb-2">24/7 Availability</h3>
                    <p className="text-gray-600">Get support whenever you need it, day or night.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="bg-purple-100 p-2 rounded-lg">
                    <Brain className="h-6 w-6 text-purple-600" />
                  </div>
                  <div>
                    <h3 className="text-lg mb-2">Evidence-Based</h3>
                    <p className="text-gray-600">Our tools are based on validated psychological screening methods (PHQ-9, GAD-7).</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="bg-orange-100 p-2 rounded-lg">
                    <Heart className="h-6 w-6 text-orange-600" />
                  </div>
                  <div>
                    <h3 className="text-lg mb-2">Culturally Sensitive</h3>
                    <p className="text-gray-600">Content available in multiple regional languages with cultural context.</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="bg-gradient-to-br from-blue-600 to-purple-600 p-8 rounded-2xl text-white">
              <h3 className="text-2xl mb-4">Crisis Support</h3>
              <p className="mb-6">If you're in immediate danger or having thoughts of self-harm, please reach out immediately:</p>
              <div className="space-y-3">
                <div className="bg-white/20 p-3 rounded-lg">
                  <div className="font-medium">National Suicide Prevention Lifeline</div>
                  <div>988 (US) | 112 (India)</div>
                </div>
                <div className="bg-white/20 p-3 rounded-lg">
                  <div className="font-medium">Campus Counseling Center</div>
                  <div>Available 24/7 via campus emergency line</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-purple-600 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl lg:text-4xl mb-6">Take the First Step Towards Better Mental Health</h2>
          <p className="text-xl mb-8 opacity-90">
            Join thousands of students who have found support and community through MindWell.
          </p>
          {!isAuthenticated && (
            <Button size="lg" variant="secondary" onClick={() => onNavigate('auth')} className="bg-white text-blue-600 hover:bg-gray-100">
              <Zap className="mr-2 h-5 w-5" />
              Get Started Today
            </Button>
          )}
        </div>
      </section>
    </div>
  );
}