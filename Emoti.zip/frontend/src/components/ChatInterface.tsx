import React, { useState, useRef, useEffect } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Avatar } from './ui/avatar';
import { Send, Bot, User, AlertTriangle, Phone, Heart } from 'lucide-react';

interface Message {
  id: string;
  content: string;
  type: 'user' | 'bot';
  timestamp: Date;
  severity?: 'low' | 'medium' | 'high' | 'crisis';
}

export function ChatInterface() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      content: "Hello! I'm your AI mental health support assistant. I'm here to listen and provide guidance. How are you feeling today?",
      type: 'bot',
      timestamp: new Date(),
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const detectSeverity = (message: string): 'low' | 'medium' | 'high' | 'crisis' => {
    const crisisKeywords = ['suicide', 'kill myself', 'end it all', 'not worth living', 'hurt myself'];
    const highKeywords = ['panic', 'can\'t cope', 'overwhelming', 'terrible', 'hopeless', 'desperate'];
    const mediumKeywords = ['anxious', 'stressed', 'worried', 'sad', 'upset', 'frustrated'];
    
    const lowerMessage = message.toLowerCase();
    
    if (crisisKeywords.some(keyword => lowerMessage.includes(keyword))) {
      return 'crisis';
    } else if (highKeywords.some(keyword => lowerMessage.includes(keyword))) {
      return 'high';
    } else if (mediumKeywords.some(keyword => lowerMessage.includes(keyword))) {
      return 'medium';
    }
    return 'low';
  };

  const generateResponse = (userMessage: string, severity: string): string => {
    if (severity === 'crisis') {
      return "I'm very concerned about what you're sharing. Your life has value and there are people who want to help. Please contact:\n\n🆘 National Suicide Prevention Lifeline: 988\n🏥 Campus Emergency: Available 24/7\n📞 Crisis Text Line: Text HOME to 741741\n\nWould you like me to help you contact a counselor right away?";
    }
    
    if (severity === 'high') {
      return "It sounds like you're going through a really tough time. That takes courage to share. Here are some immediate coping strategies:\n\n🫁 Deep breathing: 4 counts in, hold for 4, out for 6\n🚶 Take a short walk or do light stretching\n💧 Stay hydrated and get some fresh air\n\nWould you like to talk about what's making you feel this way? I'm here to listen.";
    }
    
    if (severity === 'medium') {
      return "Thank you for sharing how you're feeling. It's completely normal to experience these emotions, especially as a student. Some things that might help:\n\n📝 Try journaling your thoughts\n🎵 Listen to calming music\n👥 Reach out to a trusted friend\n⏰ Consider your sleep and eating patterns\n\nWhat's been the most challenging part of your day?";
    }
    
    // Low severity or general responses
    const responses = [
      "I hear you. Sometimes talking through our feelings can be really helpful. What's on your mind?",
      "That's a lot to process. Can you tell me more about what's been going on?",
      "It's good that you're reaching out. Taking care of your mental health is important. How has your week been?",
      "Everyone has ups and downs. What would make today a little better for you?",
      "Thank you for sharing. Sometimes the smallest steps can make a big difference. What's one thing you're grateful for today?"
    ];
    
    return responses[Math.floor(Math.random() * responses.length)];
  };

  const handleSendMessage = async () => {
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      content: inputValue,
      type: 'user',
      timestamp: new Date(),
    };

    const severity = detectSeverity(inputValue);
    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsTyping(true);

    // Simulate AI response delay
    setTimeout(() => {
      const botResponse: Message = {
        id: (Date.now() + 1).toString(),
        content: generateResponse(inputValue, severity),
        type: 'bot',
        timestamp: new Date(),
        severity,
      };
      setMessages(prev => [...prev, botResponse]);
      setIsTyping(false);
    }, 1000 + Math.random() * 2000);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const getSeverityBadge = (severity?: string) => {
    switch (severity) {
      case 'crisis':
        return <Badge className="bg-red-100 text-red-800 border-red-200">Crisis Alert</Badge>;
      case 'high':
        return <Badge className="bg-orange-100 text-orange-800 border-orange-200">High Concern</Badge>;
      case 'medium':
        return <Badge className="bg-yellow-100 text-yellow-800 border-yellow-200">Moderate</Badge>;
      default:
        return null;
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-4">
      <div className="mb-6">
        <h1 className="text-3xl mb-2">AI Mental Health Support</h1>
        <p className="text-gray-600">
          Safe, confidential, and available 24/7. This AI assistant provides coping strategies and can connect you with professional help when needed.
        </p>
      </div>

      {/* Crisis Resources */}
      <Card className="mb-6 p-4 bg-red-50 border-red-200">
        <div className="flex items-center space-x-2 mb-2">
          <AlertTriangle className="h-5 w-5 text-red-600" />
          <span className="font-medium text-red-800">Crisis Resources</span>
        </div>
        <div className="grid sm:grid-cols-2 gap-2 text-sm">
          <div className="flex items-center space-x-2">
            <Phone className="h-4 w-4 text-red-600" />
            <span>Suicide Prevention: 988</span>
          </div>
          <div className="flex items-center space-x-2">
            <Heart className="h-4 w-4 text-red-600" />
            <span>Crisis Text: HOME to 741741</span>
          </div>
        </div>
      </Card>

      {/* Chat Messages */}
      <Card className="h-96 mb-4">
        <div className="h-full flex flex-col">
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`flex items-start space-x-2 max-w-[80%] ${
                  message.type === 'user' ? 'flex-row-reverse space-x-reverse' : ''
                }`}>
                  <Avatar className="w-8 h-8 flex-shrink-0">
                    {message.type === 'user' ? (
                      <User className="h-4 w-4" />
                    ) : (
                      <Bot className="h-4 w-4" />
                    )}
                  </Avatar>
                  <div className={`rounded-lg p-3 ${
                    message.type === 'user' 
                      ? 'bg-primary text-primary-foreground' 
                      : 'bg-gray-100'
                  }`}>
                    {message.severity && getSeverityBadge(message.severity)}
                    <div className="whitespace-pre-wrap">{message.content}</div>
                    <div className={`text-xs mt-1 opacity-70 ${
                      message.type === 'user' ? 'text-primary-foreground' : 'text-gray-500'
                    }`}>
                      {message.timestamp.toLocaleTimeString()}
                    </div>
                  </div>
                </div>
              </div>
            ))}
            {isTyping && (
              <div className="flex justify-start">
                <div className="flex items-center space-x-2">
                  <Avatar className="w-8 h-8">
                    <Bot className="h-4 w-4" />
                  </Avatar>
                  <div className="bg-gray-100 rounded-lg p-3">
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                    </div>
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
          
          {/* Input Area */}
          <div className="border-t p-4">
            <div className="flex space-x-2">
              <Input
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Share how you're feeling..."
                className="flex-1"
                disabled={isTyping}
              />
              <Button 
                onClick={handleSendMessage} 
                disabled={!inputValue.trim() || isTyping}
                size="icon"
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>
            <p className="text-xs text-gray-500 mt-2">
              This AI provides support and coping strategies. For emergencies, please contact crisis services immediately.
            </p>
          </div>
        </div>
      </Card>

      {/* Quick Actions */}
      <div className="grid sm:grid-cols-3 gap-4">
        <Button 
          variant="outline" 
          className="h-auto p-4 flex flex-col items-center space-y-2"
          onClick={() => setInputValue("I'm feeling anxious about my upcoming exams")}
        >
          <span className="text-2xl">😰</span>
          <span>Academic Stress</span>
        </Button>
        <Button 
          variant="outline" 
          className="h-auto p-4 flex flex-col items-center space-y-2"
          onClick={() => setInputValue("I'm feeling lonely and isolated")}
        >
          <span className="text-2xl">😔</span>
          <span>Feeling Isolated</span>
        </Button>
        <Button 
          variant="outline" 
          className="h-auto p-4 flex flex-col items-center space-y-2"
          onClick={() => setInputValue("I'm having trouble sleeping")}
        >
          <span className="text-2xl">😴</span>
          <span>Sleep Issues</span>
        </Button>
      </div>
    </div>
  );
}