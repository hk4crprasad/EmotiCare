import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { 
  Play, 
  Download, 
  BookOpen, 
  Headphones, 
  Video, 
  Search, 
  Clock, 
  Star,
  Volume2,
  FileText,
  Globe
} from 'lucide-react';

interface Resource {
  id: string;
  title: string;
  description: string;
  type: 'video' | 'audio' | 'article' | 'guide';
  category: string;
  duration: string;
  language: string;
  rating: number;
  downloads: number;
  thumbnail?: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
}

const mockResources: Resource[] = [
  {
    id: '1',
    title: 'Deep Breathing for Anxiety Relief',
    description: 'Learn effective breathing techniques to manage anxiety and panic attacks.',
    type: 'video',
    category: 'Anxiety Management',
    duration: '8 min',
    language: 'English',
    rating: 4.8,
    downloads: 1250,
    difficulty: 'beginner'
  },
  {
    id: '2',
    title: 'Guided Sleep Meditation',
    description: 'A calming meditation to help you fall asleep naturally and peacefully.',
    type: 'audio',
    category: 'Sleep Support',
    duration: '15 min',
    language: 'Hindi',
    rating: 4.9,
    downloads: 2100,
    difficulty: 'beginner'
  },
  {
    id: '3',
    title: 'Study Stress Management Guide',
    description: 'Comprehensive strategies for managing academic pressure and exam anxiety.',
    type: 'guide',
    category: 'Academic Stress',
    duration: '20 min read',
    language: 'English',
    rating: 4.7,
    downloads: 890,
    difficulty: 'intermediate'
  },
  {
    id: '4',
    title: 'Mindfulness for Depression',
    description: 'Learn mindfulness techniques specifically designed to help with depressive thoughts.',
    type: 'video',
    category: 'Depression Support',
    duration: '12 min',
    language: 'Spanish',
    rating: 4.8,
    downloads: 1560,
    difficulty: 'intermediate'
  },
  {
    id: '5',
    title: 'Progressive Muscle Relaxation',
    description: 'Step-by-step audio guide to release physical tension and stress.',
    type: 'audio',
    category: 'Stress Relief',
    duration: '18 min',
    language: 'English',
    rating: 4.6,
    downloads: 980,
    difficulty: 'beginner'
  },
  {
    id: '6',
    title: 'Building Healthy Relationships',
    description: 'Understanding communication, boundaries, and social connections.',
    type: 'article',
    category: 'Social Wellness',
    duration: '10 min read',
    language: 'Hindi',
    rating: 4.5,
    downloads: 670,
    difficulty: 'intermediate'
  }
];

export function ResourceHub() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedLanguage, setSelectedLanguage] = useState('all');
  const [playingResource, setPlayingResource] = useState<string | null>(null);

  const categories = ['all', 'Anxiety Management', 'Sleep Support', 'Academic Stress', 'Depression Support', 'Stress Relief', 'Social Wellness'];
  const languages = ['all', 'English', 'Hindi', 'Spanish', 'Tamil', 'Telugu'];

  const filteredResources = mockResources.filter(resource => {
    const matchesSearch = resource.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         resource.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || resource.category === selectedCategory;
    const matchesLanguage = selectedLanguage === 'all' || resource.language === selectedLanguage;
    
    return matchesSearch && matchesCategory && matchesLanguage;
  });

  const getResourceIcon = (type: string) => {
    switch (type) {
      case 'video':
        return <Video className="h-5 w-5" />;
      case 'audio':
        return <Headphones className="h-5 w-5" />;
      case 'article':
        return <FileText className="h-5 w-5" />;
      case 'guide':
        return <BookOpen className="h-5 w-5" />;
      default:
        return <BookOpen className="h-5 w-5" />;
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'beginner':
        return 'bg-green-100 text-green-800';
      case 'intermediate':
        return 'bg-yellow-100 text-yellow-800';
      case 'advanced':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const handlePlayResource = (resourceId: string) => {
    setPlayingResource(playingResource === resourceId ? null : resourceId);
  };

  return (
    <div className="max-w-7xl mx-auto p-4">
      <div className="mb-8">
        <h1 className="text-3xl mb-2">Mental Health Resource Hub</h1>
        <p className="text-gray-600">
          Access videos, audio content, and guides to support your mental wellness journey. 
          All content is available in multiple regional languages.
        </p>
      </div>

      {/* Search and Filters */}
      <Card className="p-6 mb-6">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search resources..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
          <div className="flex flex-col sm:flex-row gap-4">
            <select 
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="px-3 py-2 border border-border rounded-md bg-background"
            >
              {categories.map(category => (
                <option key={category} value={category}>
                  {category === 'all' ? 'All Categories' : category}
                </option>
              ))}
            </select>
            <select 
              value={selectedLanguage}
              onChange={(e) => setSelectedLanguage(e.target.value)}
              className="px-3 py-2 border border-border rounded-md bg-background"
            >
              {languages.map(language => (
                <option key={language} value={language}>
                  {language === 'all' ? 'All Languages' : language}
                </option>
              ))}
            </select>
          </div>
        </div>
      </Card>

      {/* Featured Resource */}
      <Card className="mb-8 overflow-hidden">
        <div className="grid md:grid-cols-2 gap-0">
          <div className="relative h-64 md:h-auto">
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1636333885549-86304699925f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpdGF0aW9uJTIwcmVsYXhhdGlvbiUyMHRoZXJhcHl8ZW58MXx8fHwxNzU4MTE3MTI5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
              alt="Featured meditation content"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-black/20 flex items-center justify-center">
              <Button size="lg" className="bg-white/90 text-black hover:bg-white">
                <Play className="h-6 w-6 mr-2" />
                Featured: Daily Mindfulness Practice
              </Button>
            </div>
          </div>
          <div className="p-6">
            <Badge className="mb-3 bg-blue-100 text-blue-800">Featured Content</Badge>
            <h2 className="text-2xl mb-3">Start Your Mindfulness Journey</h2>
            <p className="text-gray-600 mb-4">
              A comprehensive 21-day program designed specifically for college students. 
              Learn practical mindfulness techniques that fit into your busy schedule.
            </p>
            <div className="flex items-center space-x-4 text-sm text-gray-500 mb-4">
              <span className="flex items-center"><Clock className="h-4 w-4 mr-1" />5-10 min/day</span>
              <span className="flex items-center"><Star className="h-4 w-4 mr-1" />4.9 rating</span>
              <span className="flex items-center"><Globe className="h-4 w-4 mr-1" />5 languages</span>
            </div>
            <Button>Start Free Program</Button>
          </div>
        </div>
      </Card>

      {/* Resource Categories */}
      <Tabs defaultValue="all" className="mb-6">
        <TabsList className="grid w-full grid-cols-4 lg:grid-cols-7">
          <TabsTrigger value="all">All</TabsTrigger>
          <TabsTrigger value="video">Videos</TabsTrigger>
          <TabsTrigger value="audio">Audio</TabsTrigger>
          <TabsTrigger value="article">Articles</TabsTrigger>
          <TabsTrigger value="guide">Guides</TabsTrigger>
          <TabsTrigger value="beginner">Beginner</TabsTrigger>
          <TabsTrigger value="popular">Popular</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="mt-6">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredResources.map((resource) => (
              <Card key={resource.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                <div className="relative h-48 bg-gradient-to-br from-blue-100 to-purple-100">
                  {resource.type === 'video' && (
                    <div className="absolute inset-0 flex items-center justify-center">
                      <Button
                        size="lg"
                        onClick={() => handlePlayResource(resource.id)}
                        className={`${playingResource === resource.id ? 'bg-red-500 hover:bg-red-600' : ''}`}
                      >
                        {playingResource === resource.id ? (
                          <>
                            <Volume2 className="h-6 w-6 mr-2" />
                            Playing...
                          </>
                        ) : (
                          <>
                            <Play className="h-6 w-6 mr-2" />
                            Watch
                          </>
                        )}
                      </Button>
                    </div>
                  )}
                  {resource.type === 'audio' && (
                    <div className="absolute inset-0 flex items-center justify-center">
                      <Button
                        size="lg"
                        onClick={() => handlePlayResource(resource.id)}
                        className={`${playingResource === resource.id ? 'bg-red-500 hover:bg-red-600' : ''}`}
                      >
                        {playingResource === resource.id ? (
                          <>
                            <Volume2 className="h-6 w-6 mr-2" />
                            Playing...
                          </>
                        ) : (
                          <>
                            <Headphones className="h-6 w-6 mr-2" />
                            Listen
                          </>
                        )}
                      </Button>
                    </div>
                  )}
                  <div className="absolute top-4 left-4">
                    <Badge className="bg-white/90 text-gray-800">
                      {getResourceIcon(resource.type)}
                      <span className="ml-1 capitalize">{resource.type}</span>
                    </Badge>
                  </div>
                  <div className="absolute top-4 right-4">
                    <Badge className={getDifficultyColor(resource.difficulty)}>
                      {resource.difficulty}
                    </Badge>
                  </div>
                </div>
                
                <div className="p-4">
                  <h3 className="font-medium text-lg mb-2">{resource.title}</h3>
                  <p className="text-gray-600 text-sm mb-3 line-clamp-2">{resource.description}</p>
                  
                  <div className="flex items-center justify-between text-sm text-gray-500 mb-3">
                    <span className="flex items-center">
                      <Clock className="h-4 w-4 mr-1" />
                      {resource.duration}
                    </span>
                    <span className="flex items-center">
                      <Star className="h-4 w-4 mr-1 text-yellow-500" />
                      {resource.rating}
                    </span>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Badge variant="outline" className="text-xs">
                        {resource.language}
                      </Badge>
                      <Badge variant="outline" className="text-xs">
                        {resource.category}
                      </Badge>
                    </div>
                    <Button size="sm" variant="ghost">
                      <Download className="h-4 w-4" />
                    </Button>
                  </div>
                  
                  <div className="mt-3 pt-3 border-t border-gray-100">
                    <div className="text-xs text-gray-500">
                      {resource.downloads} downloads
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Other tab contents would be similar filtering variations */}
        <TabsContent value="video">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredResources.filter(r => r.type === 'video').map((resource) => (
              <Card key={resource.id} className="p-4">
                <h3 className="font-medium mb-2">{resource.title}</h3>
                <p className="text-gray-600 text-sm">{resource.description}</p>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      {/* Quick Access */}
      <Card className="p-6">
        <h2 className="text-xl mb-4">Quick Access Tools</h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <Button variant="outline" className="h-auto p-4 flex flex-col items-center space-y-2">
            <span className="text-2xl">🧘</span>
            <span>5-Minute Meditation</span>
          </Button>
          <Button variant="outline" className="h-auto p-4 flex flex-col items-center space-y-2">
            <span className="text-2xl">😴</span>
            <span>Sleep Sounds</span>
          </Button>
          <Button variant="outline" className="h-auto p-4 flex flex-col items-center space-y-2">
            <span className="text-2xl">📚</span>
            <span>Study Break Timer</span>
          </Button>
          <Button variant="outline" className="h-auto p-4 flex flex-col items-center space-y-2">
            <span className="text-2xl">💪</span>
            <span>Stress Relief Exercises</span>
          </Button>
        </div>
      </Card>
    </div>
  );
}