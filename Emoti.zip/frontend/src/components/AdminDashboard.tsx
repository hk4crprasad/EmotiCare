import React, { useState } from 'react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  BarChart, 
  Bar, 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { 
  Users, 
  MessageCircle, 
  Calendar, 
  AlertTriangle, 
  TrendingUp, 
  Download,
  Eye,
  Filter,
  BookOpen
} from 'lucide-react';

// Mock data for analytics
const usageData = [
  { month: 'Jan', sessions: 120, newUsers: 45, crisisInterventions: 8 },
  { month: 'Feb', sessions: 150, newUsers: 52, crisisInterventions: 12 },
  { month: 'Mar', sessions: 180, newUsers: 68, crisisInterventions: 15 },
  { month: 'Apr', sessions: 200, newUsers: 75, crisisInterventions: 10 },
  { month: 'May', sessions: 240, newUsers: 85, crisisInterventions: 18 },
  { month: 'Jun', sessions: 280, newUsers: 95, crisisInterventions: 22 }
];

const mentalHealthTrends = [
  { category: 'Anxiety', count: 145, percentage: 35 },
  { category: 'Depression', count: 98, percentage: 24 },
  { category: 'Academic Stress', count: 87, percentage: 21 },
  { category: 'Sleep Issues', count: 52, percentage: 13 },
  { category: 'Social Isolation', count: 28, percentage: 7 }
];

const dailyActivity = [
  { hour: '6AM', interactions: 5 },
  { hour: '8AM', interactions: 12 },
  { hour: '10AM', interactions: 25 },
  { hour: '12PM', interactions: 35 },
  { hour: '2PM', interactions: 40 },
  { hour: '4PM', interactions: 38 },
  { hour: '6PM', interactions: 45 },
  { hour: '8PM', interactions: 50 },
  { hour: '10PM', interactions: 42 },
  { hour: '12AM', interactions: 28 }
];

const COLORS = ['#8884d8', '#82ca9d', '#ffc658', '#ff7300', '#8dd1e1'];

interface Alert {
  id: string;
  type: 'crisis' | 'high-usage' | 'system' | 'trend';
  message: string;
  timestamp: Date;
  severity: 'low' | 'medium' | 'high' | 'critical';
  resolved: boolean;
}

const mockAlerts: Alert[] = [
  {
    id: '1',
    type: 'crisis',
    message: 'Crisis intervention triggered - Student ID: ANON_001',
    timestamp: new Date(Date.now() - 30 * 60 * 1000),
    severity: 'critical',
    resolved: false
  },
  {
    id: '2',
    type: 'trend',
    message: 'Significant increase in anxiety-related queries (40% above average)',
    timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
    severity: 'high',
    resolved: false
  },
  {
    id: '3',
    type: 'high-usage',
    message: 'Peak usage detected - Consider additional counselor availability',
    timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000),
    severity: 'medium',
    resolved: true
  }
];

export function AdminDashboard() {
  const [selectedTimeRange, setSelectedTimeRange] = useState('6months');
  const [alerts, setAlerts] = useState(mockAlerts);

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'high':
        return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      default:
        return 'bg-blue-100 text-blue-800 border-blue-200';
    }
  };

  const markAlertResolved = (alertId: string) => {
    setAlerts(prev => prev.map(alert => 
      alert.id === alertId ? { ...alert, resolved: true } : alert
    ));
  };

  const unresolvedAlerts = alerts.filter(alert => !alert.resolved);

  return (
    <div className="max-w-7xl mx-auto p-4">
      <div className="mb-6">
        <h1 className="text-3xl mb-2">Mental Health Analytics Dashboard</h1>
        <p className="text-gray-600">
          Monitor platform usage, identify trends, and track intervention outcomes to improve student mental health support.
        </p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Users</p>
              <p className="text-2xl font-bold">1,247</p>
              <p className="text-sm text-green-600">↑ 12% this month</p>
            </div>
            <Users className="h-8 w-8 text-blue-500" />
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Active Sessions</p>
              <p className="text-2xl font-bold">280</p>
              <p className="text-sm text-green-600">↑ 8% this week</p>
            </div>
            <MessageCircle className="h-8 w-8 text-green-500" />
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Appointments</p>
              <p className="text-2xl font-bold">156</p>
              <p className="text-sm text-blue-600">32 this week</p>
            </div>
            <Calendar className="h-8 w-8 text-purple-500" />
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Crisis Alerts</p>
              <p className="text-2xl font-bold text-red-600">3</p>
              <p className="text-sm text-red-600">Requires attention</p>
            </div>
            <AlertTriangle className="h-8 w-8 text-red-500" />
          </div>
        </Card>
      </div>

      {/* Alerts Section */}
      {unresolvedAlerts.length > 0 && (
        <Card className="p-6 mb-8 border-red-200 bg-red-50">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-medium text-red-800">Active Alerts</h2>
            <Badge className="bg-red-100 text-red-800">
              {unresolvedAlerts.length} unresolved
            </Badge>
          </div>
          <div className="space-y-3">
            {unresolvedAlerts.map(alert => (
              <div key={alert.id} className="flex items-center justify-between p-3 bg-white rounded-lg border">
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-1">
                    <Badge className={getSeverityColor(alert.severity)}>
                      {alert.severity.toUpperCase()}
                    </Badge>
                    <span className="text-sm text-gray-500">
                      {alert.timestamp.toLocaleTimeString()}
                    </span>
                  </div>
                  <p className="text-sm text-gray-700">{alert.message}</p>
                </div>
                <Button 
                  size="sm" 
                  variant="outline"
                  onClick={() => markAlertResolved(alert.id)}
                >
                  Resolve
                </Button>
              </div>
            ))}
          </div>
        </Card>
      )}

      <Tabs defaultValue="overview" className="mb-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="trends">Mental Health Trends</TabsTrigger>
          <TabsTrigger value="usage">Usage Analytics</TabsTrigger>
          <TabsTrigger value="interventions">Interventions</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="mt-6">
          <div className="grid lg:grid-cols-2 gap-6">
            <Card className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-medium">Platform Usage Trends</h3>
                <select 
                  value={selectedTimeRange}
                  onChange={(e) => setSelectedTimeRange(e.target.value)}
                  className="px-3 py-1 border rounded-md text-sm bg-background"
                >
                  <option value="1month">Last Month</option>
                  <option value="3months">Last 3 Months</option>
                  <option value="6months">Last 6 Months</option>
                </select>
              </div>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={usageData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Line type="monotone" dataKey="sessions" stroke="#8884d8" strokeWidth={2} />
                  <Line type="monotone" dataKey="newUsers" stroke="#82ca9d" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </Card>

            <Card className="p-6">
              <h3 className="text-lg font-medium mb-4">Mental Health Categories</h3>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={mentalHealthTrends}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percentage }) => `${name} ${percentage}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="count"
                  >
                    {mentalHealthTrends.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </Card>
          </div>

          <Card className="p-6 mt-6">
            <h3 className="text-lg font-medium mb-4">Daily Activity Pattern</h3>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={dailyActivity}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="hour" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="interactions" fill="#8884d8" />
              </BarChart>
            </ResponsiveContainer>
          </Card>
        </TabsContent>

        <TabsContent value="trends" className="mt-6">
          <div className="grid md:grid-cols-2 gap-6">
            <Card className="p-6">
              <h3 className="text-lg font-medium mb-4">Weekly Trend Analysis</h3>
              <div className="space-y-4">
                {mentalHealthTrends.map((trend, index) => (
                  <div key={trend.category} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <span className="font-medium">{trend.category}</span>
                      <div className="text-sm text-gray-600">{trend.count} reports this week</div>
                    </div>
                    <div className="text-right">
                      <div className="text-lg font-medium">{trend.percentage}%</div>
                      <div className="text-sm text-green-600">↑ 5%</div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>

            <Card className="p-6">
              <h3 className="text-lg font-medium mb-4">Risk Assessment Summary</h3>
              <div className="space-y-3">
                <div className="flex justify-between items-center p-3 bg-red-50 rounded-lg">
                  <span>High Risk Students</span>
                  <Badge className="bg-red-100 text-red-800">12</Badge>
                </div>
                <div className="flex justify-between items-center p-3 bg-yellow-50 rounded-lg">
                  <span>Medium Risk Students</span>
                  <Badge className="bg-yellow-100 text-yellow-800">45</Badge>
                </div>
                <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
                  <span>Low Risk Students</span>
                  <Badge className="bg-green-100 text-green-800">189</Badge>
                </div>
              </div>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="usage" className="mt-6">
          <div className="grid lg:grid-cols-3 gap-6">
            <Card className="p-6">
              <h3 className="text-lg font-medium mb-4">Feature Usage</h3>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm">AI Chat Support</span>
                  <span className="font-medium">75%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-blue-600 h-2 rounded-full" style={{ width: '75%' }}></div>
                </div>
                
                <div className="flex justify-between items-center">
                  <span className="text-sm">Appointment Booking</span>
                  <span className="font-medium">45%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-green-600 h-2 rounded-full" style={{ width: '45%' }}></div>
                </div>
                
                <div className="flex justify-between items-center">
                  <span className="text-sm">Resource Hub</span>
                  <span className="font-medium">60%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-purple-600 h-2 rounded-full" style={{ width: '60%' }}></div>
                </div>
                
                <div className="flex justify-between items-center">
                  <span className="text-sm">Peer Support Forum</span>
                  <span className="font-medium">35%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-orange-600 h-2 rounded-full" style={{ width: '35%' }}></div>
                </div>
              </div>
            </Card>

            <Card className="p-6">
              <h3 className="text-lg font-medium mb-4">User Demographics</h3>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm">First Year</span>
                    <span className="font-medium">40%</span>
                  </div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm">Second Year</span>
                    <span className="font-medium">25%</span>
                  </div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm">Third Year</span>
                    <span className="font-medium">20%</span>
                  </div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm">Final Year</span>
                    <span className="font-medium">15%</span>
                  </div>
                </div>
              </div>
            </Card>

            <Card className="p-6">
              <h3 className="text-lg font-medium mb-4">Language Usage</h3>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm">English</span>
                  <span className="font-medium">65%</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">Hindi</span>
                  <span className="font-medium">20%</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">Spanish</span>
                  <span className="font-medium">10%</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">Others</span>
                  <span className="font-medium">5%</span>
                </div>
              </div>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="interventions" className="mt-6">
          <div className="grid lg:grid-cols-2 gap-6">
            <Card className="p-6">
              <h3 className="text-lg font-medium mb-4">Crisis Intervention Outcomes</h3>
              <div className="space-y-4">
                <div className="grid grid-cols-3 gap-4 text-center">
                  <div className="p-3 bg-green-50 rounded-lg">
                    <div className="text-2xl font-bold text-green-600">18</div>
                    <div className="text-sm text-gray-600">Successful</div>
                  </div>
                  <div className="p-3 bg-yellow-50 rounded-lg">
                    <div className="text-2xl font-bold text-yellow-600">5</div>
                    <div className="text-sm text-gray-600">Follow-up</div>
                  </div>
                  <div className="p-3 bg-blue-50 rounded-lg">
                    <div className="text-2xl font-bold text-blue-600">12</div>
                    <div className="text-sm text-gray-600">Referred</div>
                  </div>
                </div>
              </div>
            </Card>

            <Card className="p-6">
              <h3 className="text-lg font-medium mb-4">Response Times</h3>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm">Crisis Response</span>
                  <span className="font-medium">&lt; 2 min</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">AI Chat Response</span>
                  <span className="font-medium">&lt; 5 sec</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">Counselor Response</span>
                  <span className="font-medium">&lt; 2 hours</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">Appointment Booking</span>
                  <span className="font-medium">&lt; 1 min</span>
                </div>
              </div>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      {/* Export and Actions */}
      <Card className="p-6">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-medium">Data Export & Actions</h3>
          <div className="flex space-x-2">
            <Button variant="outline" size="sm">
              <Download className="h-4 w-4 mr-2" />
              Export Report
            </Button>
            <Button variant="outline" size="sm">
              <Eye className="h-4 w-4 mr-2" />
              View Detailed Logs
            </Button>
            <Button variant="outline" size="sm">
              <Filter className="h-4 w-4 mr-2" />
              Custom Filter
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}