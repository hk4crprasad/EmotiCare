import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Input } from './ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { Heart, User, Shield, GraduationCap, Eye, EyeOff } from 'lucide-react';

interface AuthPageProps {
  onLogin: (role: 'student' | 'counselor' | 'admin') => void;
}

export function AuthPage({ onLogin }: AuthPageProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedRole, setSelectedRole] = useState<'student' | 'counselor' | 'admin'>('student');

  const handleLogin = async (role: 'student' | 'counselor' | 'admin') => {
    setIsLoading(true);
    // Simulate authentication
    setTimeout(() => {
      setIsLoading(false);
      onLogin(role);
    }, 1000);
  };

  const demoAccounts = [
    {
      role: 'student' as const,
      email: 'student@college.edu',
      description: 'Access all student features including AI chat, booking, resources, and peer support'
    },
    {
      role: 'counselor' as const,
      email: 'counselor@college.edu',
      description: 'Manage appointments, view student interactions, and provide professional support'
    },
    {
      role: 'admin' as const,
      email: 'admin@college.edu',
      description: 'Full analytics dashboard, user management, and system administration'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 flex items-center justify-center p-4">
      <div className="max-w-md w-full space-y-6">
        {/* Header */}
        <div className="text-center">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <Heart className="h-8 w-8 text-primary" />
            <span className="text-2xl font-semibold text-primary">MindWell</span>
          </div>
          <h1 className="text-2xl mb-2">Welcome Back</h1>
          <p className="text-gray-600">Sign in to access your mental health support platform</p>
        </div>

        {/* Demo Account Quick Access */}
        <Card className="p-6">
          <h2 className="text-lg font-medium mb-4">Demo Access</h2>
          <p className="text-sm text-gray-600 mb-4">
            Try the platform with different user roles to explore all features:
          </p>
          
          <div className="space-y-3">
            {demoAccounts.map((account) => (
              <div key={account.role} className="border rounded-lg p-3 hover:bg-gray-50 transition-colors">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    {account.role === 'student' && <GraduationCap className="h-4 w-4 text-blue-500" />}
                    {account.role === 'counselor' && <User className="h-4 w-4 text-green-500" />}
                    {account.role === 'admin' && <Shield className="h-4 w-4 text-purple-500" />}
                    <span className="font-medium capitalize">{account.role}</span>
                  </div>
                  <Button 
                    size="sm" 
                    onClick={() => handleLogin(account.role)}
                    disabled={isLoading}
                  >
                    {isLoading ? 'Signing in...' : 'Try Now'}
                  </Button>
                </div>
                <p className="text-xs text-gray-600">{account.description}</p>
              </div>
            ))}
          </div>
        </Card>

        {/* Traditional Login Form */}
        <Card className="p-6">
          <Tabs defaultValue="signin">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="signin">Sign In</TabsTrigger>
              <TabsTrigger value="signup">Sign Up</TabsTrigger>
            </TabsList>

            <TabsContent value="signin" className="space-y-4 mt-4">
              <div>
                <label className="block text-sm font-medium mb-2">Email</label>
                <Input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="your.email@college.edu"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Password</label>
                <div className="relative">
                  <Input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter your password"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Role</label>
                <div className="grid grid-cols-3 gap-2">
                  {['student', 'counselor', 'admin'].map((role) => (
                    <button
                      key={role}
                      type="button"
                      onClick={() => setSelectedRole(role as any)}
                      className={`p-2 rounded-lg border text-sm capitalize ${
                        selectedRole === role 
                          ? 'border-primary bg-primary text-primary-foreground' 
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      {role}
                    </button>
                  ))}
                </div>
              </div>

              <Button 
                className="w-full" 
                onClick={() => handleLogin(selectedRole)}
                disabled={isLoading}
              >
                {isLoading ? 'Signing in...' : 'Sign In'}
              </Button>

              <div className="text-center">
                <a href="#" className="text-sm text-blue-600 hover:underline">
                  Forgot your password?
                </a>
              </div>
            </TabsContent>

            <TabsContent value="signup" className="space-y-4 mt-4">
              <div>
                <label className="block text-sm font-medium mb-2">Full Name</label>
                <Input placeholder="Enter your full name" />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">College Email</label>
                <Input type="email" placeholder="your.email@college.edu" />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Student ID</label>
                <Input placeholder="Enter your student ID" />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Password</label>
                <Input type="password" placeholder="Create a secure password" />
              </div>

              <div className="space-y-3">
                <label className="flex items-start space-x-2">
                  <input type="checkbox" className="mt-1" />
                  <span className="text-sm text-gray-600">
                    I agree to the <a href="#" className="text-blue-600 hover:underline">Terms of Service</a> and 
                    <a href="#" className="text-blue-600 hover:underline"> Privacy Policy</a>
                  </span>
                </label>
                
                <label className="flex items-start space-x-2">
                  <input type="checkbox" className="mt-1" />
                  <span className="text-sm text-gray-600">
                    I consent to receive support and educational communications
                  </span>
                </label>
              </div>

              <Button className="w-full">Create Account</Button>
            </TabsContent>
          </Tabs>
        </Card>

        {/* Privacy Notice */}
        <Card className="p-4 bg-blue-50 border-blue-200">
          <div className="flex items-start space-x-2">
            <Shield className="h-5 w-5 text-blue-600 mt-0.5 flex-shrink-0" />
            <div className="text-sm text-blue-800">
              <p className="font-medium mb-1">Privacy & Security</p>
              <p>
                Your mental health data is encrypted and confidential. We never share personal 
                information without your explicit consent. Anonymous usage data helps improve our services.
              </p>
            </div>
          </div>
        </Card>

        {/* Emergency Contact */}
        <Card className="p-4 bg-red-50 border-red-200">
          <div className="text-center text-sm text-red-800">
            <p className="font-medium mb-1">In Crisis? Get Immediate Help</p>
            <p>National Suicide Prevention Lifeline: <strong>988</strong></p>
            <p>Campus Emergency: <strong>Campus Security</strong></p>
          </div>
        </Card>
      </div>
    </div>
  );
}