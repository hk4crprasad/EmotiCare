import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Calendar, Clock, User, Phone, Video, MapPin, Check } from 'lucide-react';

interface Counselor {
  id: string;
  name: string;
  specialization: string[];
  rating: number;
  availability: string[];
  type: 'on-campus' | 'online' | 'helpline';
  languages: string[];
  nextAvailable: string;
}

interface Appointment {
  id: string;
  counselorId: string;
  date: string;
  time: string;
  type: 'video' | 'phone' | 'in-person';
  status: 'confirmed' | 'pending' | 'completed';
}

const mockCounselors: Counselor[] = [
  {
    id: '1',
    name: 'Dr. Sarah Johnson',
    specialization: ['Anxiety', 'Depression', 'Academic Stress'],
    rating: 4.9,
    availability: ['Mon 9-5', 'Wed 9-5', 'Fri 9-3'],
    type: 'on-campus',
    languages: ['English', 'Spanish'],
    nextAvailable: '2024-01-15 10:00'
  },
  {
    id: '2',
    name: 'Dr. Raj Patel',
    specialization: ['Cultural Adjustment', 'Family Issues', 'Self-esteem'],
    rating: 4.8,
    availability: ['Tue 10-6', 'Thu 10-6', 'Sat 9-1'],
    type: 'on-campus',
    languages: ['English', 'Hindi', 'Gujarati'],
    nextAvailable: '2024-01-16 14:00'
  },
  {
    id: '3',
    name: 'Crisis Support Line',
    specialization: ['Crisis Intervention', 'Emergency Support'],
    rating: 4.7,
    availability: ['24/7'],
    type: 'helpline',
    languages: ['English', 'Spanish', 'Hindi'],
    nextAvailable: 'Available Now'
  },
  {
    id: '4',
    name: 'Dr. Emily Chen',
    specialization: ['Sleep Disorders', 'Eating Disorders', 'ADHD'],
    rating: 4.9,
    availability: ['Mon-Fri 9-5'],
    type: 'online',
    languages: ['English', 'Mandarin'],
    nextAvailable: '2024-01-15 15:30'
  }
];

export function BookingSystem() {
  const [selectedCounselor, setSelectedCounselor] = useState<Counselor | null>(null);
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedTime, setSelectedTime] = useState('');
  const [appointmentType, setAppointmentType] = useState<'video' | 'phone' | 'in-person'>('video');
  const [urgency, setUrgency] = useState<'low' | 'medium' | 'high' | 'crisis'>('low');
  const [reason, setReason] = useState('');
  const [isBooked, setIsBooked] = useState(false);
  const [myAppointments] = useState<Appointment[]>([
    {
      id: '1',
      counselorId: '1',
      date: '2024-01-18',
      time: '14:00',
      type: 'video',
      status: 'confirmed'
    }
  ]);

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case 'crisis':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'high':
        return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      default:
        return 'bg-green-100 text-green-800 border-green-200';
    }
  };

  const handleBookAppointment = () => {
    if (!selectedCounselor || !selectedDate || !selectedTime) return;
    
    // Simulate booking process
    setIsBooked(true);
    setTimeout(() => {
      setIsBooked(false);
      setSelectedCounselor(null);
      setSelectedDate('');
      setSelectedTime('');
      setReason('');
    }, 3000);
  };

  const timeSlots = [
    '09:00', '09:30', '10:00', '10:30', '11:00', '11:30',
    '14:00', '14:30', '15:00', '15:30', '16:00', '16:30'
  ];

  return (
    <div className="max-w-6xl mx-auto p-4">
      <div className="mb-6">
        <h1 className="text-3xl mb-2">Book Counseling Session</h1>
        <p className="text-gray-600">
          Schedule a confidential appointment with our licensed counselors or access immediate support.
        </p>
      </div>

      {isBooked ? (
        <Card className="p-8 text-center bg-green-50 border-green-200">
          <Check className="h-16 w-16 text-green-600 mx-auto mb-4" />
          <h2 className="text-2xl mb-2 text-green-800">Appointment Confirmed!</h2>
          <p className="text-green-700 mb-4">
            Your session with {selectedCounselor?.name} has been scheduled. 
            You'll receive a confirmation email with session details.
          </p>
          <Badge className="bg-green-100 text-green-800">
            Session: {selectedDate} at {selectedTime}
          </Badge>
        </Card>
      ) : (
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Counselor Selection */}
          <div className="lg:col-span-2">
            <h2 className="text-xl mb-4">Choose Your Support</h2>
            <div className="grid gap-4">
              {mockCounselors.map((counselor) => (
                <Card 
                  key={counselor.id}
                  className={`p-4 cursor-pointer transition-all ${
                    selectedCounselor?.id === counselor.id 
                      ? 'border-primary bg-primary/5' 
                      : 'hover:border-primary/50'
                  }`}
                  onClick={() => setSelectedCounselor(counselor)}
                >
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <h3 className="font-medium text-lg">{counselor.name}</h3>
                      <div className="flex items-center space-x-2 text-sm text-gray-600">
                        <span>⭐ {counselor.rating}</span>
                        <span>•</span>
                        <span>{counselor.type.replace('-', ' ')}</span>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      {counselor.type === 'helpline' && <Phone className="h-4 w-4 text-red-500" />}
                      {counselor.type === 'online' && <Video className="h-4 w-4 text-blue-500" />}
                      {counselor.type === 'on-campus' && <MapPin className="h-4 w-4 text-green-500" />}
                    </div>
                  </div>
                  
                  <div className="mb-3">
                    <div className="flex flex-wrap gap-1 mb-2">
                      {counselor.specialization.map((spec) => (
                        <Badge key={spec} variant="secondary" className="text-xs">
                          {spec}
                        </Badge>
                      ))}
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {counselor.languages.map((lang) => (
                        <Badge key={lang} variant="outline" className="text-xs">
                          {lang}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  
                  <div className="text-sm text-gray-600">
                    <div className="flex items-center space-x-2">
                      <Clock className="h-4 w-4" />
                      <span>Next available: {counselor.nextAvailable}</span>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>

          {/* Booking Form */}
          <div>
            <Card className="p-4">
              <h3 className="text-lg mb-4">Schedule Details</h3>
              
              {selectedCounselor ? (
                <div className="space-y-4">
                  <div className="p-3 bg-gray-50 rounded-lg">
                    <div className="font-medium">{selectedCounselor.name}</div>
                    <div className="text-sm text-gray-600">{selectedCounselor.type}</div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Urgency Level</label>
                    <Select value={urgency} onValueChange={(value: any) => setUrgency(value)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low - Routine Check-in</SelectItem>
                        <SelectItem value="medium">Medium - Need Support</SelectItem>
                        <SelectItem value="high">High - Urgent Concern</SelectItem>
                        <SelectItem value="crisis">Crisis - Immediate Help</SelectItem>
                      </SelectContent>
                    </Select>
                    <Badge className={`mt-2 ${getUrgencyColor(urgency)}`}>
                      {urgency.charAt(0).toUpperCase() + urgency.slice(1)} Priority
                    </Badge>
                  </div>

                  {selectedCounselor.type !== 'helpline' && (
                    <>
                      <div>
                        <label className="block text-sm font-medium mb-2">Session Type</label>
                        <Select value={appointmentType} onValueChange={(value: any) => setAppointmentType(value)}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="video">Video Call</SelectItem>
                            <SelectItem value="phone">Phone Call</SelectItem>
                            {selectedCounselor.type === 'on-campus' && (
                              <SelectItem value="in-person">In-Person</SelectItem>
                            )}
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <label className="block text-sm font-medium mb-2">Preferred Date</label>
                        <Input
                          type="date"
                          value={selectedDate}
                          onChange={(e) => setSelectedDate(e.target.value)}
                          min={new Date().toISOString().split('T')[0]}
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium mb-2">Time Slot</label>
                        <div className="grid grid-cols-3 gap-2">
                          {timeSlots.map((time) => (
                            <Button
                              key={time}
                              variant={selectedTime === time ? "default" : "outline"}
                              size="sm"
                              onClick={() => setSelectedTime(time)}
                              className="text-xs"
                            >
                              {time}
                            </Button>
                          ))}
                        </div>
                      </div>
                    </>
                  )}

                  <div>
                    <label className="block text-sm font-medium mb-2">
                      Reason for Session (Optional)
                    </label>
                    <Textarea
                      value={reason}
                      onChange={(e) => setReason(e.target.value)}
                      placeholder="Briefly describe what you'd like to discuss..."
                      className="resize-none"
                      rows={3}
                    />
                  </div>

                  <Button 
                    onClick={handleBookAppointment}
                    className="w-full"
                    disabled={selectedCounselor.type !== 'helpline' && (!selectedDate || !selectedTime)}
                  >
                    {selectedCounselor.type === 'helpline' ? 'Call Now' : 'Book Appointment'}
                  </Button>

                  <p className="text-xs text-gray-500 text-center">
                    All sessions are confidential and secure
                  </p>
                </div>
              ) : (
                <p className="text-gray-500 text-center py-8">
                  Select a counselor to schedule your appointment
                </p>
              )}
            </Card>

            {/* My Appointments */}
            {myAppointments.length > 0 && (
              <Card className="p-4 mt-4">
                <h3 className="text-lg mb-3">Upcoming Appointments</h3>
                {myAppointments.map((appointment) => {
                  const counselor = mockCounselors.find(c => c.id === appointment.counselorId);
                  return (
                    <div key={appointment.id} className="p-3 bg-gray-50 rounded-lg">
                      <div className="font-medium">{counselor?.name}</div>
                      <div className="text-sm text-gray-600">
                        {appointment.date} at {appointment.time}
                      </div>
                      <div className="flex items-center space-x-2 mt-2">
                        <Badge variant="outline">{appointment.type}</Badge>
                        <Badge className="bg-green-100 text-green-800">
                          {appointment.status}
                        </Badge>
                      </div>
                    </div>
                  );
                })}
              </Card>
            )}
          </div>
        </div>
      )}
    </div>
  );
}