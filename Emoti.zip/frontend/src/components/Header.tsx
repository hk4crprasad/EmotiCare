import React from 'react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Heart, MessageCircle, Calendar, BookOpen, Users, BarChart3, LogOut, User } from 'lucide-react';

interface HeaderProps {
  currentPage: string;
  onNavigate: (page: any) => void;
  isAuthenticated: boolean;
  userRole: 'student' | 'counselor' | 'admin';
  onLogout: () => void;
}

export function Header({ currentPage, onNavigate, isAuthenticated, userRole, onLogout }: HeaderProps) {
  const navigationItems = [
    { id: 'home', label: 'Home', icon: Heart },
    { id: 'chat', label: 'AI Support', icon: MessageCircle },
    { id: 'booking', label: 'Book Session', icon: Calendar },
    { id: 'resources', label: 'Resources', icon: BookOpen },
    { id: 'forum', label: 'Peer Support', icon: Users },
  ];

  if (userRole === 'admin') {
    navigationItems.push({ id: 'admin', label: 'Dashboard', icon: BarChart3 });
  }

  return (
    <header className="bg-white border-b border-border sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-8">
            <div 
              className="flex items-center space-x-2 cursor-pointer"
              onClick={() => onNavigate('home')}
            >
              <Heart className="h-8 w-8 text-primary" />
              <span className="text-xl font-semibold text-primary">MindWell</span>
            </div>
            
            <nav className="hidden md:flex space-x-1">
              {navigationItems.map((item) => {
                const Icon = item.icon;
                return (
                  <Button
                    key={item.id}
                    variant={currentPage === item.id ? "default" : "ghost"}
                    onClick={() => onNavigate(item.id)}
                    className="flex items-center space-x-2"
                  >
                    <Icon className="h-4 w-4" />
                    <span>{item.label}</span>
                  </Button>
                );
              })}
            </nav>
          </div>

          <div className="flex items-center space-x-4">
            {isAuthenticated ? (
              <>
                <div className="flex items-center space-x-2">
                  <User className="h-4 w-4" />
                  <span className="text-sm">{userRole}</span>
                  <Badge variant="secondary">
                    {userRole.charAt(0).toUpperCase() + userRole.slice(1)}
                  </Badge>
                </div>
                <Button variant="outline" onClick={onLogout} size="sm">
                  <LogOut className="h-4 w-4 mr-2" />
                  Logout
                </Button>
              </>
            ) : (
              <Button onClick={() => onNavigate('auth')}>
                Sign In
              </Button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}