import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Badge } from '../ui/badge';
import { Textarea } from '../ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { ScrollArea } from '../ui/scroll-area';
import { Separator } from '../ui/separator';
import { 
  MessageCircle, 
  Send, 
  Plus, 
  AlertTriangle, 
  Heart,
  Lightbulb
} from 'lucide-react';
import { api } from '../../lib/api';

interface Message {
  role: 'user' | 'assistant';
  content: string;
  timestamp?: string;
}

interface ChatSession {
  id: string;
  emotional_state: string;
  status: string;
  created_at: string;
  message_count: number;
  messages?: Message[];
}

export function ChatInterface() {
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [currentSession, setCurrentSession] = useState<ChatSession | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [showNewSessionForm, setShowNewSessionForm] = useState(false);
  const [newSessionData, setNewSessionData] = useState({
    initial_message: '',
    emotional_state: ''
  });
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    loadChatSessions();
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const loadChatSessions = async () => {
    try {
      const sessions = await api.getChatSessions();
      setSessions(sessions);
    } catch (error) {
      console.error('Error loading chat sessions:', error);
    }
  };

  const loadSessionMessages = async (sessionId: string) => {
    try {
      const session = await api.getChatSession(sessionId);
      setCurrentSession(session);
      setMessages(session.messages || []);
    } catch (error) {
      console.error('Error loading session messages:', error);
    }
  };

  const startNewSession = async () => {
    if (!newSessionData.initial_message || !newSessionData.emotional_state) return;

    setIsLoading(true);
    try {
      const session = await api.startChatSession(
        newSessionData.initial_message,
        newSessionData.emotional_state
      );
      setCurrentSession(session);
      setMessages(session.messages || []);
      setShowNewSessionForm(false);
      setNewSessionData({ initial_message: '', emotional_state: '' });
      await loadChatSessions();
    } catch (error) {
      console.error('Error starting new session:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const sendMessage = async () => {
    if (!newMessage.trim() || !currentSession || isLoading) return;

    const userMessage: Message = {
      role: 'user',
      content: newMessage,
      timestamp: new Date().toISOString()
    };

    setMessages(prev => [...prev, userMessage]);
    setNewMessage('');
    setIsLoading(true);

    try {
      const response = await api.sendChatMessage(currentSession.id, newMessage);
      
      const assistantMessage: Message = {
        role: 'assistant',
        content: response.message,
        timestamp: new Date().toISOString()
      };

      setMessages(prev => [...prev, assistantMessage]);

      // Check for intervention requirements
      if (response.requires_intervention) {
        // Show emergency resources or alert
        console.log('Intervention required:', response);
      }
    } catch (error) {
      console.error('Error sending message:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const endSession = async () => {
    if (!currentSession) return;

    try {
      await api.endChatSession(currentSession.id);
      setCurrentSession(null);
      setMessages([]);
      await loadChatSessions();
    } catch (error) {
      console.error('Error ending session:', error);
    }
  };

  const getEmotionalStateColor = (state: string) => {
    const colors: { [key: string]: string } = {
      anxious: 'bg-yellow-100 text-yellow-800',
      depressed: 'bg-blue-100 text-blue-800',
      stressed: 'bg-red-100 text-red-800',
      angry: 'bg-orange-100 text-orange-800',
      sad: 'bg-gray-100 text-gray-800',
      happy: 'bg-green-100 text-green-800',
      neutral: 'bg-gray-100 text-gray-800'
    };
    return colors[state] || 'bg-gray-100 text-gray-800';
  };

  return (
    <div className="h-full flex">
      {/* Sidebar with chat sessions */}
      <div className="w-80 border-r bg-muted/50 flex flex-col">
        <div className="p-4 border-b">
          <div className="flex items-center justify-between mb-2">
            <h2 className="text-lg font-semibold">Chat Sessions</h2>
            <Button
              size="sm"
              onClick={() => setShowNewSessionForm(true)}
              disabled={showNewSessionForm}
            >
              <Plus className="h-4 w-4" />
            </Button>
          </div>
          <p className="text-sm text-muted-foreground">
            AI-powered emotional support
          </p>
        </div>

        <ScrollArea className="flex-1">
          <div className="p-4 space-y-3">
            {showNewSessionForm && (
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm">New Session</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div>
                    <label className="text-xs font-medium mb-1 block">
                      How are you feeling?
                    </label>
                    <Select
                      value={newSessionData.emotional_state}
                      onValueChange={(value) => 
                        setNewSessionData(prev => ({ ...prev, emotional_state: value }))
                      }
                    >
                      <SelectTrigger className="h-8">
                        <SelectValue placeholder="Select emotion" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="anxious">Anxious</SelectItem>
                        <SelectItem value="depressed">Depressed</SelectItem>
                        <SelectItem value="stressed">Stressed</SelectItem>
                        <SelectItem value="angry">Angry</SelectItem>
                        <SelectItem value="sad">Sad</SelectItem>
                        <SelectItem value="neutral">Neutral</SelectItem>
                        <SelectItem value="happy">Happy</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-xs font-medium mb-1 block">
                      What's on your mind?
                    </label>
                    <Textarea
                      placeholder="Tell me what's bothering you..."
                      value={newSessionData.initial_message}
                      onChange={(e) => 
                        setNewSessionData(prev => ({ ...prev, initial_message: e.target.value }))
                      }
                      className="h-20 text-sm"
                    />
                  </div>
                  <div className="flex gap-2">
                    <Button 
                      size="sm" 
                      onClick={startNewSession}
                      disabled={isLoading || !newSessionData.initial_message || !newSessionData.emotional_state}
                      className="flex-1"
                    >
                      Start Chat
                    </Button>
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => setShowNewSessionForm(false)}
                    >
                      Cancel
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {sessions.map((session) => (
              <Card 
                key={session.id}
                className={`cursor-pointer transition-colors ${
                  currentSession?.id === session.id ? 'border-primary' : ''
                }`}
                onClick={() => loadSessionMessages(session.id)}
              >
                <CardContent className="p-3">
                  <div className="flex items-center justify-between mb-2">
                    <Badge 
                      variant="outline" 
                      className={getEmotionalStateColor(session.emotional_state)}
                    >
                      {session.emotional_state}
                    </Badge>
                    <Badge variant={session.status === 'active' ? 'default' : 'secondary'}>
                      {session.status}
                    </Badge>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {session.message_count} messages
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {new Date(session.created_at).toLocaleDateString()}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </ScrollArea>
      </div>

      {/* Main chat area */}
      <div className="flex-1 flex flex-col">
        {currentSession ? (
          <>
            {/* Chat header */}
            <div className="p-4 border-b bg-background">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-semibold">Chat Session</h3>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge className={getEmotionalStateColor(currentSession.emotional_state)}>
                      {currentSession.emotional_state}
                    </Badge>
                    <Badge variant={currentSession.status === 'active' ? 'default' : 'secondary'}>
                      {currentSession.status}
                    </Badge>
                  </div>
                </div>
                {currentSession.status === 'active' && (
                  <Button variant="outline" size="sm" onClick={endSession}>
                    End Session
                  </Button>
                )}
              </div>
            </div>

            {/* Messages */}
            <ScrollArea className="flex-1 p-4">
              <div className="space-y-4 max-w-3xl mx-auto">
                {messages.map((message, index) => (
                  <div
                    key={index}
                    className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div
                      className={`max-w-[80%] rounded-lg p-3 ${
                        message.role === 'user'
                          ? 'bg-primary text-primary-foreground'
                          : 'bg-muted'
                      }`}
                    >
                      <p className="text-sm">{message.content}</p>
                      {message.timestamp && (
                        <p className="text-xs opacity-70 mt-1">
                          {new Date(message.timestamp).toLocaleTimeString()}
                        </p>
                      )}
                    </div>
                  </div>
                ))}
                {isLoading && (
                  <div className="flex justify-start">
                    <div className="bg-muted rounded-lg p-3">
                      <p className="text-sm">AI is typing...</p>
                    </div>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </div>
            </ScrollArea>

            {/* Message input */}
            {currentSession.status === 'active' && (
              <div className="p-4 border-t bg-background">
                <div className="flex gap-2 max-w-3xl mx-auto">
                  <Input
                    placeholder="Type your message..."
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                    disabled={isLoading}
                  />
                  <Button onClick={sendMessage} disabled={isLoading || !newMessage.trim()}>
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            )}
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center space-y-4">
              <MessageCircle className="mx-auto h-16 w-16 text-muted-foreground" />
              <div>
                <h3 className="text-lg font-semibold">Welcome to AI Chat Support</h3>
                <p className="text-muted-foreground max-w-md mx-auto">
                  Get 24/7 emotional support from our AI counselor. 
                  Start a new chat session or continue an existing conversation.
                </p>
              </div>
              <div className="flex flex-col items-center gap-3">
                <Button onClick={() => setShowNewSessionForm(true)}>
                  <Plus className="mr-2 h-4 w-4" />
                  Start New Chat Session
                </Button>
                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <Heart className="h-4 w-4" />
                    <span>24/7 Support</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <AlertTriangle className="h-4 w-4" />
                    <span>Crisis Detection</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Lightbulb className="h-4 w-4" />
                    <span>Personalized Help</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}