#!/bin/bash

# EmotiCare Frontend Installation Script

echo "🌟 EmotiCare Frontend Installation"
echo "=================================="

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js 16.x or higher."
    exit 1
fi

# Check Node.js version
NODE_VERSION=$(node --version | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 16 ]; then
    echo "❌ Node.js version 16 or higher is required. Current version: $(node --version)"
    exit 1
fi

echo "✅ Node.js version: $(node --version)"

# Install dependencies
echo "📦 Installing dependencies..."
npm install

if [ $? -eq 0 ]; then
    echo "✅ Dependencies installed successfully!"
else
    echo "❌ Failed to install dependencies."
    exit 1
fi

# Create environment file if it doesn't exist
if [ ! -f ".env.local" ]; then
    echo "🔧 Creating environment configuration..."
    cat > .env.local << EOL
# EmotiCare Frontend Environment Configuration
REACT_APP_API_URL=http://localhost:8000
REACT_APP_WS_URL=ws://localhost:8000
REACT_APP_NAME=EmotiCare
REACT_APP_VERSION=1.0.0
REACT_APP_ENABLE_VOICE_CHAT=true
REACT_APP_ENABLE_PEER_SUPPORT=true
REACT_APP_ENABLE_ASSESSMENTS=true
REACT_APP_CRISIS_HOTLINE=988
REACT_APP_EMERGENCY_NUMBER=911
GENERATE_SOURCEMAP=true
REACT_APP_DEBUG_MODE=false
EOL
    echo "✅ Environment file created!"
else
    echo "✅ Environment file already exists!"
fi

echo ""
echo "🎉 Installation completed successfully!"
echo ""
echo "Next steps:"
echo "1. Make sure the EmotiCare backend is running on http://localhost:8000"
echo "2. Start the development server: npm start"
echo "3. Open http://localhost:3000 in your browser"
echo ""
echo "For more information, see the README.md file."
