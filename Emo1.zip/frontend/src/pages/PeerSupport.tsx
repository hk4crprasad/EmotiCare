import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  UsersIcon,
  PlusIcon,
  HeartIcon,
  ChatBubbleLeftIcon,
} from '@heroicons/react/24/outline';
import { peerSupportAPI, postsAPI } from '../services/api';
import { PeerSupportPost, Post } from '../types';
import { formatDateTime } from '../utils';

const PeerSupport: React.FC = () => {
  const [posts, setPosts] = useState<PeerSupportPost[]>([]);
  const [motivationalPosts, setMotivationalPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [newPost, setNewPost] = useState('');
  const [isAnonymous, setIsAnonymous] = useState(true);
  const [showCreatePost, setShowCreatePost] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const supportRes = await peerSupportAPI.getPosts();
        setPosts(supportRes.data);
        
        try {
          const feedRes = await postsAPI.getFeed(1, 10);
          setMotivationalPosts(feedRes.data.posts);
        } catch (error) {
          console.error('Error fetching motivational posts:', error);
          setMotivationalPosts([]);
        }
      } catch (error) {
        console.error('Error fetching peer support data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const handleCreatePost = async () => {
    if (!newPost.trim()) return;

    try {
      const response = await peerSupportAPI.createPost({
        content: newPost.trim(),
        anonymous: isAnonymous,
      });
      setPosts([response.data, ...posts]);
      setNewPost('');
      setShowCreatePost(false);
    } catch (error) {
      console.error('Error creating post:', error);
    }
  };

  if (loading) {
    return (
      <div className="p-6">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-gray-200 rounded w-1/4"></div>
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="h-32 bg-gray-200 rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Peer Support</h1>
            <p className="text-lg text-gray-600">
              Connect with fellow students and share your experiences
            </p>
          </div>
          <button
            onClick={() => setShowCreatePost(true)}
            className="btn-primary"
          >
            <PlusIcon className="h-5 w-5 mr-2" />
            Share
          </button>
        </div>
      </motion.div>

      {/* Create Post Modal/Form */}
      {showCreatePost && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="card mb-6"
        >
          <div className="card-body">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Share Your Thoughts</h3>
            <textarea
              value={newPost}
              onChange={(e) => setNewPost(e.target.value)}
              placeholder="What's on your mind? Share your experiences, ask for support, or offer encouragement..."
              rows={4}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 resize-none"
            />
            <div className="mt-4 flex items-center justify-between">
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={isAnonymous}
                  onChange={(e) => setIsAnonymous(e.target.checked)}
                  className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
                />
                <span className="ml-2 text-sm text-gray-700">Post anonymously</span>
              </label>
              <div className="space-x-3">
                <button
                  onClick={() => setShowCreatePost(false)}
                  className="btn-outline"
                >
                  Cancel
                </button>
                <button
                  onClick={handleCreatePost}
                  disabled={!newPost.trim()}
                  className="btn-primary disabled:opacity-50"
                >
                  Share
                </button>
              </div>
            </div>
          </div>
        </motion.div>
      )}

      {/* Support Posts */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="space-y-6"
      >
        {posts.length > 0 ? (
          posts.map((post, index) => (
            <motion.div
              key={post.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 + index * 0.1 }}
              className="card"
            >
              <div className="card-body">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center space-x-3">
                    <div className="h-10 w-10 bg-gradient-primary rounded-full flex items-center justify-center">
                      <UsersIcon className="h-5 w-5 text-white" />
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">{post.author}</p>
                      <p className="text-sm text-gray-500">{formatDateTime(post.created_at)}</p>
                    </div>
                  </div>
                  {post.anonymous && (
                    <span className="badge badge-info">Anonymous</span>
                  )}
                </div>
                
                <p className="text-gray-800 mb-4 whitespace-pre-wrap">{post.content}</p>
                
                <div className="flex items-center justify-between">
                  <button className="flex items-center space-x-2 text-gray-500 hover:text-primary-600 transition-colors">
                    <HeartIcon className="h-5 w-5" />
                    <span>{post.likes}</span>
                  </button>
                  <button className="flex items-center space-x-2 text-gray-500 hover:text-primary-600 transition-colors">
                    <ChatBubbleLeftIcon className="h-5 w-5" />
                    <span>Reply</span>
                  </button>
                </div>
              </div>
            </motion.div>
          ))
        ) : (
          <div className="text-center py-12">
            <UsersIcon className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-medium text-gray-900 mb-2">No posts yet</h3>
            <p className="text-gray-600 mb-6">
              Be the first to share your experience and connect with others
            </p>
            <button
              onClick={() => setShowCreatePost(true)}
              className="btn-primary"
            >
              Start the Conversation
            </button>
          </div>
        )}

        {/* Motivational Section */}
        {motivationalPosts.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="mt-12"
          >
            <h2 className="text-xl font-semibold text-gray-900 mb-6">Motivational Posts</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {motivationalPosts.slice(0, 4).map((post) => (
                <div key={post.id} className="card bg-gradient-to-br from-primary-50 to-calm-50">
                  <div className="card-body">
                    <p className="text-gray-800 mb-3">{post.content}</p>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-600">by {post.author}</span>
                      <div className="flex items-center space-x-2">
                        <HeartIcon className="h-4 w-4 text-red-500" />
                        <span className="text-gray-600">{post.likes_count}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </motion.div>
    </div>
  );
};

export default PeerSupport;
