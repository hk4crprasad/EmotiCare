import React, { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  MicrophoneIcon,
  StopIcon,
  SpeakerWaveIcon,
  ExclamationTriangleIcon,
  PhoneIcon,
} from '@heroicons/react/24/outline';
import { VoiceMessage, VoiceResponse } from '../types';

const VoiceChat: React.FC = () => {
  const [isConnected, setIsConnected] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [messages, setMessages] = useState<VoiceResponse[]>([]);
  const [connectionStatus, setConnectionStatus] = useState('disconnected');
  const wsRef = useRef<WebSocket | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);

  useEffect(() => {
    return () => {
      // Cleanup on unmount
      if (wsRef.current) {
        wsRef.current.close();
      }
      if (mediaRecorderRef.current && isRecording) {
        mediaRecorderRef.current.stop();
      }
    };
  }, [isRecording]);

  const connectToVoiceChat = async () => {
    try {
      const token = localStorage.getItem('access_token');
      if (!token) return;

      const wsUrl = `ws://localhost:8000/api/v1/voice/ws/voice-chat?token=${token}`;
      const ws = new WebSocket(wsUrl);

      ws.onopen = () => {
        setIsConnected(true);
        setConnectionStatus('connected');
        console.log('Voice chat connected');
      };

      ws.onmessage = (event) => {
        const response: VoiceResponse = JSON.parse(event.data);
        setMessages(prev => [...prev, response]);

        switch (response.type) {
          case 'welcome':
            setTranscript(response.message || '');
            break;
          case 'transcript':
            setTranscript(response.text || '');
            break;
          case 'text_response':
            // Play text-to-speech if available
            if (response.text) {
              speakText(response.text);
            }
            break;
          case 'audio_response':
            // Play audio response
            if (response.audio_data) {
              playAudioData(response.audio_data);
            }
            break;
          case 'crisis_alert':
            // Handle crisis alert
            alert('Crisis support activated. Emergency resources have been provided.');
            break;
          case 'error':
            console.error('Voice chat error:', response.message);
            break;
        }
      };

      ws.onerror = (error) => {
        console.error('WebSocket error:', error);
        setConnectionStatus('error');
      };

      ws.onclose = () => {
        setIsConnected(false);
        setConnectionStatus('disconnected');
        console.log('Voice chat disconnected');
      };

      wsRef.current = ws;
    } catch (error) {
      console.error('Error connecting to voice chat:', error);
      setConnectionStatus('error');
    }
  };

  const disconnectFromVoiceChat = () => {
    if (wsRef.current) {
      wsRef.current.close();
    }
    setIsConnected(false);
    setIsRecording(false);
    setMessages([]);
    setTranscript('');
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;

      const audioChunks: Blob[] = [];

      mediaRecorder.ondataavailable = (event) => {
        audioChunks.push(event.data);
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunks, { type: 'audio/wav' });
        sendAudioToServer(audioBlob);
        
        // Stop all tracks to release microphone
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
    } catch (error) {
      console.error('Error starting recording:', error);
      alert('Unable to access microphone. Please check your permissions.');
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const sendAudioToServer = async (audioBlob: Blob) => {
    if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) return;

    const reader = new FileReader();
    reader.onload = () => {
      const base64Audio = (reader.result as string).split(',')[1];
      const message: VoiceMessage = {
        type: 'audio_chunk',
        audio_data: base64Audio,
        format: 'wav',
        sample_rate: 16000,
      };
      wsRef.current?.send(JSON.stringify(message));
    };
    reader.readAsDataURL(audioBlob);
  };

  const speakText = (text: string) => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.onstart = () => setIsPlaying(true);
      utterance.onend = () => setIsPlaying(false);
      speechSynthesis.speak(utterance);
    }
  };

  const playAudioData = (base64Audio: string) => {
    try {
      const audio = new Audio(`data:audio/wav;base64,${base64Audio}`);
      audio.onplay = () => setIsPlaying(true);
      audio.onended = () => setIsPlaying(false);
      audio.play();
    } catch (error) {
      console.error('Error playing audio:', error);
    }
  };

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-8"
      >
        <div className="mx-auto h-16 w-16 bg-gradient-primary rounded-full flex items-center justify-center mb-4">
          <MicrophoneIcon className="h-8 w-8 text-white" />
        </div>
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Voice Chat Support</h1>
        <p className="text-lg text-gray-600">
          Have a conversation with our AI counselor using your voice
        </p>
      </motion.div>

      {/* Connection Status */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="card mb-6"
      >
        <div className="card-body">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className={`h-3 w-3 rounded-full ${
                connectionStatus === 'connected' ? 'bg-green-500' :
                connectionStatus === 'error' ? 'bg-red-500' : 'bg-gray-400'
              }`} />
              <span className="font-medium text-gray-900">
                {connectionStatus === 'connected' ? 'Connected' :
                 connectionStatus === 'error' ? 'Connection Error' : 'Disconnected'}
              </span>
            </div>
            {!isConnected ? (
              <button
                onClick={connectToVoiceChat}
                className="btn-primary"
              >
                Connect to Voice Chat
              </button>
            ) : (
              <button
                onClick={disconnectFromVoiceChat}
                className="btn-danger"
              >
                Disconnect
              </button>
            )}
          </div>
        </div>
      </motion.div>

      {isConnected && (
        <>
          {/* Voice Controls */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="card mb-6"
          >
            <div className="card-body text-center">
              <div className="mb-6">
                <button
                  onClick={isRecording ? stopRecording : startRecording}
                  disabled={!isConnected}
                  className={`h-20 w-20 rounded-full flex items-center justify-center transition-all duration-200 ${
                    isRecording
                      ? 'bg-red-500 hover:bg-red-600 animate-pulse'
                      : 'bg-primary-500 hover:bg-primary-600'
                  } text-white disabled:opacity-50 disabled:cursor-not-allowed`}
                >
                  {isRecording ? (
                    <StopIcon className="h-8 w-8" />
                  ) : (
                    <MicrophoneIcon className="h-8 w-8" />
                  )}
                </button>
              </div>
              
              <p className="text-lg font-medium text-gray-900 mb-2">
                {isRecording ? 'Recording... Speak now' : 'Click to start speaking'}
              </p>
              
              {isPlaying && (
                <div className="flex items-center justify-center space-x-2 text-primary-600">
                  <SpeakerWaveIcon className="h-5 w-5 animate-pulse" />
                  <span className="text-sm">AI is responding...</span>
                </div>
              )}
            </div>
          </motion.div>

          {/* Transcript */}
          {transcript && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="card mb-6"
            >
              <div className="card-body">
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Current Transcript</h3>
                <p className="text-gray-800 bg-gray-50 p-3 rounded-lg">
                  {transcript}
                </p>
              </div>
            </motion.div>
          )}

          {/* Conversation History */}
          {messages.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="card"
            >
              <div className="card-header">
                <h3 className="text-lg font-semibold text-gray-900">Conversation History</h3>
              </div>
              <div className="card-body">
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {messages.map((message, index) => (
                    <div
                      key={index}
                      className={`p-3 rounded-lg ${
                        message.type === 'transcript' ? 'bg-blue-50' : 'bg-gray-50'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs font-medium text-gray-500 uppercase">
                          {message.type.replace('_', ' ')}
                        </span>
                        <span className="text-xs text-gray-500">
                          {new Date(message.timestamp).toLocaleTimeString()}
                        </span>
                      </div>
                      <p className="text-gray-800">
                        {message.message || message.text || 'Audio response'}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          )}
        </>
      )}

      {/* Emergency Support */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="mt-8"
      >
        <div className="card bg-red-50 border-red-200">
          <div className="card-body">
            <div className="flex items-center">
              <ExclamationTriangleIcon className="h-8 w-8 text-red-600 mr-4" />
              <div className="flex-1">
                <h3 className="text-lg font-medium text-red-900">Crisis Support</h3>
                <p className="text-red-700">
                  If you're experiencing a mental health emergency, please call for immediate help.
                </p>
              </div>
              <div className="ml-4 space-x-3">
                <a
                  href="tel:988"
                  className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-red-600 hover:bg-red-700"
                >
                  <PhoneIcon className="h-4 w-4 mr-2" />
                  Call 988
                </a>
              </div>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Browser Compatibility Notice */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        className="mt-6"
      >
        <div className="card bg-blue-50 border-blue-200">
          <div className="card-body">
            <h4 className="font-medium text-blue-900 mb-2">Browser Requirements</h4>
            <p className="text-sm text-blue-700">
              Voice chat requires microphone access and a modern browser. Please ensure you've granted microphone permissions when prompted.
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default VoiceChat;
