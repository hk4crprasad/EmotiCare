import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  ClipboardDocumentListIcon,
  ChartBarIcon,
  PlusIcon,
} from '@heroicons/react/24/outline';
import { assessmentsAPI } from '../services/api';
import { Assessment, AssessmentType } from '../types';
import { formatDate, getAssessmentRiskColor } from '../utils';

const Assessments: React.FC = () => {
  const [assessments, setAssessments] = useState<Assessment[]>([]);
  const [availableTypes, setAvailableTypes] = useState<AssessmentType[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [assessmentsRes, typesRes] = await Promise.all([
          assessmentsAPI.getAssessments(),
          assessmentsAPI.getAvailableTypes(),
        ]);
        setAssessments(assessmentsRes.data);
        setAvailableTypes(typesRes.data);
      } catch (error) {
        console.error('Error fetching assessments:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  if (loading) {
    return (
      <div className="p-6">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-gray-200 rounded w-1/4"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="h-48 bg-gray-200 rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Mental Health Assessments</h1>
        <p className="text-lg text-gray-600">
          Track your mental wellness with validated assessment tools
        </p>
      </motion.div>

      {/* Available Assessments */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="mb-8"
      >
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Available Assessments</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {availableTypes.map((type, index) => (
            <motion.div
              key={type.type}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 + index * 0.1 }}
              className="card hover:shadow-lg transition-shadow duration-200"
            >
              <div className="card-body">
                <div className="flex items-center justify-between mb-4">
                  <ClipboardDocumentListIcon className="h-8 w-8 text-primary-600" />
                  <button className="btn-primary">
                    Take Assessment
                  </button>
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  {type.name}
                </h3>
                <p className="text-gray-600 text-sm">
                  {type.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Assessment History */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
      >
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Assessment History</h2>
        <div className="card">
          <div className="card-body">
            {assessments.length > 0 ? (
              <div className="space-y-4">
                {assessments.map((assessment) => (
                  <div
                    key={assessment.id}
                    className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
                  >
                    <div>
                      <h3 className="font-medium text-gray-900">
                        {assessment.assessment_type.replace('_', ' ').toUpperCase()}
                      </h3>
                      <p className="text-sm text-gray-500">
                        {formatDate(assessment.completed_at)}
                      </p>
                    </div>
                    <div className="flex items-center space-x-4">
                      <span className={`px-3 py-1 rounded-full text-sm font-medium ${getAssessmentRiskColor(assessment.interpretation)}`}>
                        {assessment.interpretation}
                      </span>
                      <span className="text-lg font-bold text-gray-900">
                        {assessment.score}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <ChartBarIcon className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500 mb-4">No assessments taken yet</p>
                <button className="btn-primary">
                  <PlusIcon className="h-4 w-4 mr-2" />
                  Take Your First Assessment
                </button>
              </div>
            )}
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default Assessments;
