// User types
export interface User {
  id: string;
  email: string;
  full_name: string;
  role: 'student' | 'counselor' | 'admin';
  is_active: boolean;
  student_id?: string;
  phone_number?: string;
  created_at?: string;
}

export interface LoginRequest {
  username: string;
  password: string;
}

export interface RegisterRequest {
  email: string;
  full_name: string;
  password: string;
  role: 'student' | 'counselor';
  student_id?: string;
}

export interface AuthResponse {
  access_token: string;
  token_type: string;
  expires_in: number;
  user: User;
}

// Chat types
export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
  timestamp?: string;
}

export interface ChatSession {
  id: string;
  user_id: string;
  messages: ChatMessage[];
  status: 'active' | 'ended';
  emotional_state: string;
  created_at: string;
  message_count?: number;
}

export interface ChatResponse {
  message: string;
  requires_intervention: boolean;
  emotional_support_level: string;
  suggested_resources: string[];
}

// Assessment types
export interface AssessmentQuestion {
  id: string;
  text: string;
  options: string[];
}

export interface Assessment {
  id: string;
  user_id: string;
  assessment_type: string;
  responses: Record<string, number>;
  score: number;
  interpretation: string;
  recommendations: string[];
  completed_at: string;
}

export interface AssessmentType {
  type: string;
  name: string;
  description: string;
}

// Appointment types
export interface Counselor {
  id: string;
  name: string;
  specialization: string;
  rating: number;
  available_today: boolean;
}

export interface Appointment {
  id: string;
  counselor_id: string;
  counselor_name: string;
  appointment_date: string;
  start_time: string;
  end_time: string;
  status: 'scheduled' | 'completed' | 'cancelled';
  appointment_type: string;
  mode?: 'in-person' | 'online';
  reason?: string;
}

export interface TimeSlot {
  date: string;
  start_time: string;
  end_time: string;
  available: boolean;
}

// Resource types
export interface Resource {
  id: string;
  title?: string;
  content?: string;
  type?: 'article' | 'video' | 'exercise' | 'document';
  category?: string;
  rating?: number;
  relevance_score?: number;
}

export interface ResourceCategory {
  name: string;
  display_name: string;
}

// Post types
export interface Post {
  id: string;
  author: string;
  content: string;
  hashtags: string[];
  likes_count: number;
  comments_count?: number;
  created_at: string;
  updated_at?: string;
  visibility?: 'public' | 'private';
}

export interface PeerSupportPost {
  id: string;
  author: string;
  content: string;
  likes: number;
  created_at: string;
  anonymous?: boolean;
}

// Voice Chat types
export interface VoiceMessage {
  type: 'audio_chunk' | 'text_input' | 'ping' | 'end_session';
  audio_data?: string;
  text?: string;
  format?: string;
  sample_rate?: number;
}

export interface VoiceResponse {
  type: 'welcome' | 'transcript' | 'text_response' | 'audio_response' | 'status' | 'crisis_alert' | 'error' | 'pong';
  message?: string;
  text?: string;
  audio_data?: string;
  format?: string;
  session_id?: string;
  timestamp: string;
  resources?: any[];
}

// API Response types
export interface ApiResponse<T> {
  data: T;
  message?: string;
  status?: string;
}

export interface PaginatedResponse<T> {
  data: T[];
  total_pages: number;
  current_page: number;
  total_count?: number;
}

export interface PostsFeedResponse {
  posts: Post[];
  total_pages: number;
  current_page: number;
}

// Dashboard types
export interface EmotionalInsight {
  date: string;
  primary_emotion: string;
  intensity: number;
}

export interface DashboardStats {
  total_assessments: number;
  upcoming_appointments: number;
  completed_resources: number;
  current_emotional_state: string;
}
