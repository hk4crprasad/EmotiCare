import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import {
  ChatBubbleLeftRightIcon,
  ClipboardDocumentListIcon,
  CalendarDaysIcon,
  BookOpenIcon,
  HeartIcon,
  ExclamationTriangleIcon,
} from '@heroicons/react/24/outline';
import { motion } from 'framer-motion';
import { assessmentsAPI, appointmentsAPI, resourcesAPI, chatAPI } from '../../services/api';
import { Assessment, Appointment, Resource, ChatSession } from '../../types';
import { formatDate, formatTime, getAssessmentRiskColor, getEmotionalStateColor } from '../../utils';

const Dashboard: React.FC = () => {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [dashboardData, setDashboardData] = useState({
    recentAssessments: [] as Assessment[],
    upcomingAppointments: [] as Appointment[],
    recommendedResources: [] as Resource[],
    recentChatSessions: [] as ChatSession[],
    stats: {
      totalAssessments: 0,
      upcomingAppointments: 0,
      completedResources: 0,
      currentMood: 'neutral' as string,
    },
  });

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        setLoading(true);
        
        // Fetch data in parallel
        const [assessments, appointments, resources, chatSessions] = await Promise.all([
          assessmentsAPI.getAssessments().catch(() => ({ data: [] })),
          appointmentsAPI.getMyAppointments().catch(() => ({ data: [] })),
          resourcesAPI.getRecommended().catch(() => ({ data: [] })),
          chatAPI.getSessions().catch(() => ({ data: [] })),
        ]);

        // Process upcoming appointments (filter future appointments)
        const now = new Date();
        const upcoming = appointments.data.filter(apt => {
          const aptDate = new Date(`${apt.appointment_date}T${apt.start_time}`);
          return aptDate > now && apt.status === 'scheduled';
        }).slice(0, 3);

        // Get recent assessments (last 5)
        const recent = assessments.data
          .sort((a, b) => new Date(b.completed_at).getTime() - new Date(a.completed_at).getTime())
          .slice(0, 3);

        // Get recent chat sessions
        const recentChats = chatSessions.data
          .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
          .slice(0, 3);

        // Calculate current mood from recent assessments or chat sessions
        let currentMood = 'neutral';
        if (recentChats.length > 0) {
          currentMood = recentChats[0].emotional_state;
        } else if (recent.length > 0) {
          const latestAssessment = recent[0];
          if (latestAssessment.score <= 5) currentMood = 'good';
          else if (latestAssessment.score <= 10) currentMood = 'okay';
          else if (latestAssessment.score <= 15) currentMood = 'concerned';
          else currentMood = 'needs attention';
        }

        setDashboardData({
          recentAssessments: recent,
          upcomingAppointments: upcoming,
          recommendedResources: resources.data.slice(0, 4),
          recentChatSessions: recentChats,
          stats: {
            totalAssessments: assessments.data.length,
            upcomingAppointments: upcoming.length,
            completedResources: 0, // We'll fetch this separately if needed
            currentMood,
          },
        });
      } catch (error) {
        console.error('Error fetching dashboard data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchDashboardData();
  }, []);

  const quickActions = [
    {
      name: 'Start AI Chat',
      description: 'Talk to our AI counselor',
      href: '/chat',
      icon: ChatBubbleLeftRightIcon,
      color: 'bg-blue-500 hover:bg-blue-600',
    },
    {
      name: 'Take Assessment',
      description: 'Check your mental health',
      href: '/assessments',
      icon: ClipboardDocumentListIcon,
      color: 'bg-green-500 hover:bg-green-600',
    },
    {
      name: 'Book Appointment',
      description: 'Schedule with a counselor',
      href: '/appointments',
      icon: CalendarDaysIcon,
      color: 'bg-purple-500 hover:bg-purple-600',
    },
    {
      name: 'Browse Resources',
      description: 'Find helpful content',
      href: '/resources',
      icon: BookOpenIcon,
      color: 'bg-orange-500 hover:bg-orange-600',
    },
  ];

  if (loading) {
    return (
      <div className="p-6">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-gray-200 rounded w-1/4"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-32 bg-gray-200 rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Welcome Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <h1 className="text-3xl font-bold text-gray-900 mb-2">
          Welcome back, {user?.full_name.split(' ')[0]} 👋
        </h1>
        <p className="text-lg text-gray-600">
          How are you feeling today? We're here to support your mental wellness journey.
        </p>
      </motion.div>

      {/* Current Mood Status */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="mb-8"
      >
        <div className="card bg-gradient-to-r from-calm-50 to-primary-50 border-calm-200">
          <div className="card-body">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="h-12 w-12 bg-white rounded-full flex items-center justify-center">
                  <HeartIcon className="h-6 w-6 text-primary-600" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">Current Mood</h3>
                  <div className="flex items-center space-x-2">
                    <span className={`px-3 py-1 rounded-full text-sm font-medium ${getEmotionalStateColor(dashboardData.stats.currentMood)}`}>
                      {dashboardData.stats.currentMood}
                    </span>
                    <span className="text-sm text-gray-600">
                      Based on your recent activity
                    </span>
                  </div>
                </div>
              </div>
              <Link
                to="/chat"
                className="btn-primary"
              >
                Talk Now
              </Link>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Quick Actions */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mb-8"
      >
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Quick Actions</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {quickActions.map((action, index) => {
            const Icon = action.icon;
            return (
              <motion.div
                key={action.name}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 + index * 0.1 }}
              >
                <Link
                  to={action.href}
                  className="group block card hover:shadow-lg transition-shadow duration-200"
                >
                  <div className="card-body text-center">
                    <div className={`inline-flex h-12 w-12 items-center justify-center rounded-lg ${action.color} mb-3 transition-colors duration-200`}>
                      <Icon className="h-6 w-6 text-white" />
                    </div>
                    <h3 className="text-lg font-medium text-gray-900 group-hover:text-primary-600">
                      {action.name}
                    </h3>
                    <p className="text-sm text-gray-500">{action.description}</p>
                  </div>
                </Link>
              </motion.div>
            );
          })}
        </div>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Recent Assessments */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.4 }}
          className="card"
        >
          <div className="card-header">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium text-gray-900">Recent Assessments</h3>
              <Link to="/assessments" className="text-sm text-primary-600 hover:text-primary-500">
                View all
              </Link>
            </div>
          </div>
          <div className="card-body">
            {dashboardData.recentAssessments.length > 0 ? (
              <div className="space-y-4">
                {dashboardData.recentAssessments.map((assessment) => (
                  <div key={assessment.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <p className="font-medium text-gray-900">
                        {assessment.assessment_type.replace('_', ' ').toUpperCase()}
                      </p>
                      <p className="text-sm text-gray-500">
                        {formatDate(assessment.completed_at)}
                      </p>
                    </div>
                    <div className="text-right">
                      <span className={`px-2 py-1 rounded text-xs font-medium ${getAssessmentRiskColor(assessment.interpretation)}`}>
                        {assessment.interpretation}
                      </span>
                      <p className="text-sm text-gray-500 mt-1">
                        Score: {assessment.score}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-6">
                <ClipboardDocumentListIcon className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500 mb-4">No assessments taken yet</p>
                <Link to="/assessments" className="btn-primary">
                  Take Your First Assessment
                </Link>
              </div>
            )}
          </div>
        </motion.div>

        {/* Upcoming Appointments */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.5 }}
          className="card"
        >
          <div className="card-header">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium text-gray-900">Upcoming Appointments</h3>
              <Link to="/appointments" className="text-sm text-primary-600 hover:text-primary-500">
                View all
              </Link>
            </div>
          </div>
          <div className="card-body">
            {dashboardData.upcomingAppointments.length > 0 ? (
              <div className="space-y-4">
                {dashboardData.upcomingAppointments.map((appointment) => (
                  <div key={appointment.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <p className="font-medium text-gray-900">
                        Dr. {appointment.counselor_name}
                      </p>
                      <p className="text-sm text-gray-500">
                        {appointment.appointment_type}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium text-gray-900">
                        {formatDate(appointment.appointment_date)}
                      </p>
                      <p className="text-sm text-gray-500">
                        {formatTime(appointment.start_time)}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-6">
                <CalendarDaysIcon className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500 mb-4">No upcoming appointments</p>
                <Link to="/appointments" className="btn-primary">
                  Schedule Appointment
                </Link>
              </div>
            )}
          </div>
        </motion.div>
      </div>

      {/* Recommended Resources */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        className="mt-8"
      >
        <div className="card">
          <div className="card-header">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium text-gray-900">Recommended Resources</h3>
              <Link to="/resources" className="text-sm text-primary-600 hover:text-primary-500">
                View all
              </Link>
            </div>
          </div>
          <div className="card-body">
            {dashboardData.recommendedResources.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {dashboardData.recommendedResources.map((resource) => (
                  <Link
                    key={resource.id}
                    to={`/resources/${resource.id}`}
                    className="group block p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors duration-200"
                  >
                    <div className="flex items-center space-x-3">
                      <div className="flex-shrink-0">
                        <span className="text-2xl">{resource.type === 'video' ? '🎥' : resource.type === 'article' ? '📰' : '📚'}</span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-gray-900 group-hover:text-primary-600 truncate">
                          {resource.title}
                        </p>
                        <p className="text-xs text-gray-500 capitalize">
                          {resource.type} • {resource.category}
                        </p>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            ) : (
              <div className="text-center py-6">
                <BookOpenIcon className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500 mb-4">No resources available</p>
                <Link to="/resources" className="btn-primary">
                  Browse Resources
                </Link>
              </div>
            )}
          </div>
        </div>
      </motion.div>

      {/* Emergency Support */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.7 }}
        className="mt-8"
      >
        <div className="card bg-red-50 border-red-200">
          <div className="card-body">
            <div className="flex items-center">
              <ExclamationTriangleIcon className="h-8 w-8 text-red-600 mr-4" />
              <div className="flex-1">
                <h3 className="text-lg font-medium text-red-900">Need immediate help?</h3>
                <p className="text-red-700">
                  If you're experiencing a mental health crisis, reach out for immediate support.
                </p>
              </div>
              <div className="ml-4 space-x-3">
                <a
                  href="tel:988"
                  className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-red-600 hover:bg-red-700"
                >
                  Call 988
                </a>
                <Link
                  to="/chat"
                  className="inline-flex items-center px-4 py-2 border border-red-300 text-sm font-medium rounded-md text-red-700 bg-white hover:bg-red-50"
                >
                  Crisis Chat
                </Link>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default Dashboard;
