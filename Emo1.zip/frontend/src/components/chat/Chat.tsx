import React, { useState, useEffect, useRef } from 'react';
import {
  PaperAirplaneIcon,
  ExclamationTriangleIcon,
  PhoneIcon,
  ChatBubbleLeftRightIcon,
  FaceSmileIcon,
  HeartIcon,
} from '@heroicons/react/24/outline';
import { motion, AnimatePresence } from 'framer-motion';
import { chatAPI } from '../../services/api';
import { ChatSession, ChatMessage } from '../../types';
import { formatDateTime, containsCrisisKeywords } from '../../utils';
import { toast } from 'react-toastify';

const Chat: React.FC = () => {
  const [currentSession, setCurrentSession] = useState<ChatSession | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputMessage, setInputMessage] = useState('');
  const [emotionalState, setEmotionalState] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [showEmergencyResources, setShowEmergencyResources] = useState(false);
  const [isSessionStarted, setIsSessionStarted] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const emotionalStates = [
    { value: 'positive', emoji: '😊', label: 'Happy' },
    { value: 'calm', emoji: '😌', label: 'Calm' },
    { value: 'distressed', emoji: '😰', label: 'Anxious' },
    { value: 'distressed', emoji: '😵', label: 'Stressed' },
    { value: 'distressed', emoji: '😢', label: 'Sad' },
    { value: 'very_distressed', emoji: '😠', label: 'Angry' },
    { value: 'very_distressed', emoji: '🤯', label: 'Overwhelmed' },
    { value: 'neutral', emoji: '😐', label: 'Neutral' },
  ];

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const startChatSession = async (initialMessage: string, selectedState: string) => {
    try {
      setIsLoading(true);
      const response = await chatAPI.startSession({
        initial_message: initialMessage,
        emotional_state: selectedState,
      });

      setCurrentSession(response.data);
      setMessages(response.data.messages);
      setIsSessionStarted(true);
      setInputMessage('');
      setEmotionalState('');

      // Check for crisis keywords
      if (containsCrisisKeywords(initialMessage)) {
        setShowEmergencyResources(true);
      }
    } catch (error: any) {
      toast.error('Failed to start chat session. Please try again.');
      console.error('Chat session error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const sendMessage = async () => {
    if (!inputMessage.trim() || !currentSession || isLoading) return;

    const userMessage: ChatMessage = {
      role: 'user',
      content: inputMessage.trim(),
      timestamp: new Date().toISOString(),
    };

    setMessages(prev => [...prev, userMessage]);
    const messageToSend = inputMessage.trim();
    setInputMessage('');
    setIsLoading(true);

    try {
      const response = await chatAPI.sendMessage(currentSession.id, messageToSend);
      
      const assistantMessage: ChatMessage = {
        role: 'assistant',
        content: response.data.message,
        timestamp: new Date().toISOString(),
      };

      setMessages(prev => [...prev, assistantMessage]);

      // Check if intervention is required
      if (response.data.requires_intervention) {
        setShowEmergencyResources(true);
      }

      // Check for crisis keywords in user message
      if (containsCrisisKeywords(messageToSend)) {
        setShowEmergencyResources(true);
      }
    } catch (error: any) {
      toast.error('Failed to send message. Please try again.');
      console.error('Send message error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const endSession = async () => {
    if (!currentSession) return;

    try {
      await chatAPI.endSession(currentSession.id);
      setCurrentSession(null);
      setMessages([]);
      setIsSessionStarted(false);
      setShowEmergencyResources(false);
      toast.success('Chat session ended. Take care of yourself! 💙');
    } catch (error: any) {
      console.error('End session error:', error);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      if (isSessionStarted) {
        sendMessage();
      } else if (inputMessage.trim() && emotionalState) {
        startChatSession(inputMessage.trim(), emotionalState);
      }
    }
  };

  if (!isSessionStarted) {
    return (
      <div className="p-6 max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <div className="mx-auto h-16 w-16 bg-gradient-primary rounded-full flex items-center justify-center mb-4">
            <ChatBubbleLeftRightIcon className="h-8 w-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">AI Mental Health Support</h1>
          <p className="text-lg text-gray-600">
            Start a conversation with our AI counselor. Share what's on your mind.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="card max-w-2xl mx-auto"
        >
          <div className="card-body space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">
                How are you feeling right now?
              </label>
              <div className="grid grid-cols-4 gap-3">
                {emotionalStates.map((state) => (
                  <button
                    key={state.value}
                    onClick={() => setEmotionalState(state.value)}
                    className={`p-3 rounded-lg border text-center transition-colors duration-200 ${
                      emotionalState === state.value
                        ? 'border-primary-500 bg-primary-50 text-primary-700'
                        : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                    }`}
                  >
                    <div className="text-2xl mb-1">{state.emoji}</div>
                    <div className="text-xs font-medium">{state.label}</div>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label htmlFor="initial-message" className="block text-sm font-medium text-gray-700 mb-2">
                What would you like to talk about?
              </label>
              <textarea
                id="initial-message"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Share what's on your mind... I'm here to listen and support you."
                rows={4}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500 resize-none"
              />
            </div>

            <button
              onClick={() => emotionalState && inputMessage.trim() && startChatSession(inputMessage.trim(), emotionalState)}
              disabled={!emotionalState || !inputMessage.trim() || isLoading}
              className="w-full btn-primary py-3 text-base disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? (
                <div className="flex items-center justify-center">
                  <div className="loading-spinner mr-2"></div>
                  Starting conversation...
                </div>
              ) : (
                'Start Conversation'
              )}
            </button>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="mt-8 text-center"
        >
          <div className="card bg-red-50 border-red-200 max-w-2xl mx-auto">
            <div className="card-body">
              <div className="flex items-center justify-center mb-3">
                <ExclamationTriangleIcon className="h-6 w-6 text-red-600 mr-2" />
                <span className="font-medium text-red-900">Crisis Support</span>
              </div>
              <p className="text-red-700 text-sm mb-4">
                If you're having thoughts of self-harm or suicide, please reach out for immediate help.
              </p>
              <div className="flex justify-center space-x-4">
                <a
                  href="tel:988"
                  className="inline-flex items-center px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
                >
                  <PhoneIcon className="h-4 w-4 mr-2" />
                  Call 988
                </a>
                <a
                  href="tel:911"
                  className="inline-flex items-center px-4 py-2 bg-red-800 text-white rounded-lg hover:bg-red-900 transition-colors"
                >
                  <PhoneIcon className="h-4 w-4 mr-2" />
                  Emergency 911
                </a>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="h-10 w-10 bg-gradient-primary rounded-full flex items-center justify-center">
              <HeartIcon className="h-5 w-5 text-white" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-gray-900">AI Counselor</h2>
              <p className="text-sm text-gray-500">Here to support you</p>
            </div>
          </div>
          <button
            onClick={endSession}
            className="btn-outline text-sm"
          >
            End Session
          </button>
        </div>
      </div>

      {/* Emergency Resources Alert */}
      <AnimatePresence>
        {showEmergencyResources && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="bg-red-50 border-b border-red-200 px-6 py-3"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <ExclamationTriangleIcon className="h-5 w-5 text-red-600 mr-2" />
                <span className="text-sm text-red-800 font-medium">
                  Crisis support resources are available if you need immediate help
                </span>
              </div>
              <div className="flex space-x-2">
                <a
                  href="tel:988"
                  className="text-xs bg-red-600 text-white px-3 py-1 rounded hover:bg-red-700"
                >
                  Call 988
                </a>
                <button
                  onClick={() => setShowEmergencyResources(false)}
                  className="text-xs text-red-600 hover:text-red-800"
                >
                  ✕
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
        <AnimatePresence>
          {messages.map((message, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                message.role === 'user'
                  ? 'bg-primary-600 text-white'
                  : 'bg-gray-100 text-gray-900'
              }`}>
                {message.role === 'assistant' && (
                  <div className="flex items-center mb-1">
                    <FaceSmileIcon className="h-4 w-4 text-primary-600 mr-1" />
                    <span className="text-xs text-gray-500 font-medium">AI Counselor</span>
                  </div>
                )}
                <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                {message.timestamp && (
                  <p className={`text-xs mt-1 ${
                    message.role === 'user' ? 'text-primary-200' : 'text-gray-500'
                  }`}>
                    {formatDateTime(message.timestamp)}
                  </p>
                )}
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
        
        {isLoading && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex justify-start"
          >
            <div className="bg-gray-100 rounded-lg px-4 py-2">
              <div className="flex items-center space-x-2">
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                </div>
                <span className="text-xs text-gray-500">AI is typing...</span>
              </div>
            </div>
          </motion.div>
        )}
        
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="bg-white border-t border-gray-200 px-6 py-4">
        <div className="flex space-x-4">
          <textarea
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Type your message here..."
            rows={2}
            className="flex-1 px-3 py-2 border border-gray-300 rounded-lg shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500 resize-none"
            disabled={isLoading}
          />
          <button
            onClick={sendMessage}
            disabled={!inputMessage.trim() || isLoading}
            className="flex-shrink-0 btn-primary px-4 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <PaperAirplaneIcon className="h-5 w-5" />
          </button>
        </div>
        <p className="text-xs text-gray-500 mt-2">
          Press Enter to send • Shift+Enter for new line
        </p>
      </div>
    </div>
  );
};

export default Chat;
