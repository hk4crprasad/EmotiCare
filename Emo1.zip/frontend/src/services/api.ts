import axios, { AxiosResponse } from 'axios';
import {
  User,
  LoginRequest,
  RegisterRequest,
  AuthResponse,
  ChatSession,
  ChatResponse,
  Assessment,
  AssessmentType,
  AssessmentQuestion,
  Appointment,
  Counselor,
  TimeSlot,
  Resource,
  ResourceCategory,
  Post,
  PeerSupportPost,
  PaginatedResponse,
  PostsFeedResponse,
} from '../types';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000';

// Create axios instance
const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor to add auth token
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('access_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Response interceptor for error handling
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('access_token');
      localStorage.removeItem('user');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// Auth API
export const authAPI = {
  register: (data: RegisterRequest): Promise<AxiosResponse<User>> =>
    api.post('/api/v1/auth/register', data),

  login: (data: LoginRequest): Promise<AxiosResponse<AuthResponse>> =>
    api.post('/api/v1/auth/login', data, {
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    }),

  getCurrentUser: (): Promise<AxiosResponse<User>> =>
    api.get('/api/v1/auth/me'),

  updateProfile: (data: Partial<User>): Promise<AxiosResponse<User>> =>
    api.put('/api/v1/auth/me', data),

  changePassword: (data: { current_password: string; new_password: string }): Promise<AxiosResponse<{ message: string }>> =>
    api.post('/api/v1/auth/change-password', data),

  logout: (): Promise<AxiosResponse<{ message: string }>> =>
    api.post('/api/v1/auth/logout'),
};

// Chat API
export const chatAPI = {
  startSession: (data: { initial_message: string; emotional_state: string }): Promise<AxiosResponse<ChatSession>> =>
    api.post('/api/v1/chat/start-session', data),

  sendMessage: (sessionId: string, message: string): Promise<AxiosResponse<ChatResponse>> =>
    api.post(`/api/v1/chat/sessions/${sessionId}/message`, { message }),

  getSessions: (): Promise<AxiosResponse<ChatSession[]>> =>
    api.get('/api/v1/chat/sessions'),

  getSession: (sessionId: string): Promise<AxiosResponse<ChatSession>> =>
    api.get(`/api/v1/chat/sessions/${sessionId}`),

  endSession: (sessionId: string): Promise<AxiosResponse<{ message: string }>> =>
    api.post(`/api/v1/chat/sessions/${sessionId}/end`),

  getEmergencyResources: (): Promise<AxiosResponse<any>> =>
    api.get('/api/v1/chat/emergency-resources'),
};

// Assessments API
export const assessmentsAPI = {
  submitAssessment: (data: { assessment_type: string; responses: Record<string, number> }): Promise<AxiosResponse<Assessment>> =>
    api.post('/api/v1/assessments/', data),

  getAssessments: (): Promise<AxiosResponse<Assessment[]>> =>
    api.get('/api/v1/assessments/'),

  getAssessment: (assessmentId: string): Promise<AxiosResponse<Assessment>> =>
    api.get(`/api/v1/assessments/${assessmentId}`),

  getDashboardSummary: (): Promise<AxiosResponse<any[]>> =>
    api.get('/api/v1/assessments/summary/dashboard'),

  getAvailableTypes: (): Promise<AxiosResponse<AssessmentType[]>> =>
    api.get('/api/v1/assessments/types/available'),

  getQuestions: (assessmentType: string): Promise<AxiosResponse<{ assessment_type: string; questions: AssessmentQuestion[] }>> =>
    api.get(`/api/v1/assessments/questions/${assessmentType}`),
};

// Appointments API
export const appointmentsAPI = {
  bookAppointment: (data: {
    counselor_id: string;
    appointment_date: string;
    start_time: string;
    end_time: string;
    appointment_type: string;
    mode: string;
    reason: string;
    urgency_level: string;
  }): Promise<AxiosResponse<{ appointment_id: string; status: string; message: string }>> =>
    api.post('/api/v1/appointments/book', data),

  getAvailableSlots: (counselorId: string, date: string): Promise<AxiosResponse<TimeSlot[]>> =>
    api.get(`/api/v1/appointments/available-slots?counselor_id=${counselorId}&date=${date}`),

  getMyAppointments: (): Promise<AxiosResponse<Appointment[]>> =>
    api.get('/api/v1/appointments/my-appointments'),

  updateAppointment: (appointmentId: string, data: { status: string; reason?: string }): Promise<AxiosResponse<Appointment>> =>
    api.put(`/api/v1/appointments/${appointmentId}`, data),

  cancelAppointment: (appointmentId: string): Promise<AxiosResponse<{ message: string }>> =>
    api.delete(`/api/v1/appointments/${appointmentId}`),

  getCounselors: (): Promise<AxiosResponse<Counselor[]>> =>
    api.get('/api/v1/appointments/counselors'),
};

// Resources API
export const resourcesAPI = {
  getResources: (): Promise<AxiosResponse<Resource[]>> =>
    api.get('/api/v1/resources/'),

  getCategories: (): Promise<AxiosResponse<ResourceCategory[]>> =>
    api.get('/api/v1/resources/categories'),

  getTypes: (): Promise<AxiosResponse<any[]>> =>
    api.get('/api/v1/resources/types'),

  getRecommended: (): Promise<AxiosResponse<Resource[]>> =>
    api.get('/api/v1/resources/recommended'),

  getResource: (resourceId: string): Promise<AxiosResponse<Resource>> =>
    api.get(`/api/v1/resources/${resourceId}`),

  rateResource: (resourceId: string, rating: number): Promise<AxiosResponse<{ message: string; new_average_rating: number }>> =>
    api.post(`/api/v1/resources/${resourceId}/rate`, { rating }),

  completeResource: (resourceId: string): Promise<AxiosResponse<{ message: string; progress_percentage: number }>> =>
    api.post(`/api/v1/resources/${resourceId}/complete`),

  getUserProgress: (): Promise<AxiosResponse<any[]>> =>
    api.get('/api/v1/resources/user/progress'),

  searchResources: (query: string, category?: string): Promise<AxiosResponse<Resource[]>> =>
    api.get(`/api/v1/resources/search?q=${query}${category ? `&category=${category}` : ''}`),
};

// Peer Support API
export const peerSupportAPI = {
  getPosts: (): Promise<AxiosResponse<PeerSupportPost[]>> =>
    api.get('/api/v1/peer-support/posts'),

  createPost: (data: { content: string; anonymous: boolean }): Promise<AxiosResponse<PeerSupportPost>> =>
    api.post('/api/v1/peer-support/posts', data),
};

// Posts API
export const postsAPI = {
  createPost: (data: { content: string; hashtags: string[]; visibility: string }): Promise<AxiosResponse<Post>> =>
    api.post('/api/v1/posts/', data),

  getFeed: (page: number = 1, limit: number = 10): Promise<AxiosResponse<PostsFeedResponse>> =>
    api.get(`/api/v1/posts/feed?page=${page}&limit=${limit}`),

  searchPosts: (query: string, hashtags?: string): Promise<AxiosResponse<PaginatedResponse<Post>>> =>
    api.get(`/api/v1/posts/search?q=${query}${hashtags ? `&hashtags=${hashtags}` : ''}`),

  getTrendingHashtags: (): Promise<AxiosResponse<any[]>> =>
    api.get('/api/v1/posts/hashtags/trending'),

  getPost: (postId: string): Promise<AxiosResponse<Post>> =>
    api.get(`/api/v1/posts/${postId}`),

  updatePost: (postId: string, data: { content: string }): Promise<AxiosResponse<Post>> =>
    api.put(`/api/v1/posts/${postId}`, data),

  deletePost: (postId: string): Promise<AxiosResponse<{ message: string }>> =>
    api.delete(`/api/v1/posts/${postId}`),

  likePost: (postId: string): Promise<AxiosResponse<{ message: string; likes_count: number }>> =>
    api.post(`/api/v1/posts/${postId}/like`),

  bookmarkPost: (postId: string): Promise<AxiosResponse<{ message: string }>> =>
    api.post(`/api/v1/posts/${postId}/bookmark`),
};

// Voice Chat API
export const voiceChatAPI = {
  getStatus: (): Promise<AxiosResponse<any>> =>
    api.get('/api/v1/voice/voice-chat/status'),
};

// Health check
export const healthAPI = {
  check: (): Promise<AxiosResponse<{ status: string; app_name: string; version: string }>> =>
    api.get('/health'),
};

export default api;
