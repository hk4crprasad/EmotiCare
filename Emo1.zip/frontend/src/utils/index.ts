import { format, parseISO, isToday, isTomorrow, isYesterday } from 'date-fns';

// Date formatting utilities
export const formatDate = (dateString: string): string => {
  try {
    const date = parseISO(dateString);
    
    if (isToday(date)) {
      return 'Today';
    } else if (isTomorrow(date)) {
      return 'Tomorrow';
    } else if (isYesterday(date)) {
      return 'Yesterday';
    } else {
      return format(date, 'MMM d, yyyy');
    }
  } catch (error) {
    return dateString;
  }
};

export const formatTime = (timeString: string): string => {
  try {
    const [hours, minutes] = timeString.split(':');
    const hour = parseInt(hours, 10);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const hour12 = hour % 12 || 12;
    return `${hour12}:${minutes} ${ampm}`;
  } catch (error) {
    return timeString;
  }
};

export const formatDateTime = (dateTimeString: string): string => {
  try {
    const date = parseISO(dateTimeString);
    return format(date, 'MMM d, yyyy at h:mm a');
  } catch (error) {
    return dateTimeString;
  }
};

// Local storage utilities
export const getFromStorage = <T>(key: string, defaultValue: T): T => {
  try {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : defaultValue;
  } catch (error) {
    console.error(`Error getting ${key} from localStorage:`, error);
    return defaultValue;
  }
};

export const setToStorage = (key: string, value: any): void => {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (error) {
    console.error(`Error setting ${key} to localStorage:`, error);
  }
};

export const removeFromStorage = (key: string): void => {
  try {
    localStorage.removeItem(key);
  } catch (error) {
    console.error(`Error removing ${key} from localStorage:`, error);
  }
};

// Assessment scoring utilities
export const calculateAssessmentRisk = (score: number, assessmentType: string): string => {
  if (assessmentType === 'depression_phq9') {
    if (score <= 4) return 'Minimal';
    if (score <= 9) return 'Mild';
    if (score <= 14) return 'Moderate';
    if (score <= 19) return 'Moderately Severe';
    return 'Severe';
  } else if (assessmentType === 'anxiety_gad7') {
    if (score <= 4) return 'Minimal';
    if (score <= 9) return 'Mild';
    if (score <= 14) return 'Moderate';
    return 'Severe';
  }
  return 'Unknown';
};

export const getAssessmentRiskColor = (risk: string | undefined): string => {
  if (!risk) {
    return 'text-gray-600 bg-gray-50';
  }
  
  switch (risk.toLowerCase()) {
    case 'minimal':
      return 'text-green-600 bg-green-50';
    case 'mild':
      return 'text-yellow-600 bg-yellow-50';
    case 'moderate':
      return 'text-orange-600 bg-orange-50';
    case 'moderately severe':
    case 'severe':
      return 'text-red-600 bg-red-50';
    default:
      return 'text-gray-600 bg-gray-50';
  }
};

// Emotional state utilities
export const getEmotionalStateColor = (state: string | undefined): string => {
  if (!state) {
    return 'text-gray-600 bg-gray-50';
  }
  
  const lowerState = state.toLowerCase();
  
  if (lowerState.includes('positive') || lowerState.includes('happy') || lowerState.includes('joy')) {
    return 'text-green-600 bg-green-50';
  } else if (lowerState.includes('calm') || lowerState.includes('peaceful')) {
    return 'text-blue-600 bg-blue-50';
  } else if (lowerState.includes('neutral')) {
    return 'text-gray-600 bg-gray-50';
  } else if (lowerState.includes('distressed') || lowerState.includes('anxious') || lowerState.includes('worry') || lowerState.includes('stress') || lowerState.includes('sad')) {
    return 'text-yellow-600 bg-yellow-50';
  } else if (lowerState.includes('very_distressed') || lowerState.includes('angry') || lowerState.includes('overwhelm')) {
    return 'text-red-600 bg-red-50';
  }
  
  return 'text-gray-600 bg-gray-50';
};

// Text utilities
export const truncateText = (text: string, maxLength: number): string => {
  if (text.length <= maxLength) return text;
  return text.substring(0, maxLength) + '...';
};

export const capitalizeFirstLetter = (string: string): string => {
  return string.charAt(0).toUpperCase() + string.slice(1);
};

// Validation utilities
export const isValidEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

export const isValidPassword = (password: string): boolean => {
  // At least 8 characters, 1 uppercase, 1 lowercase, 1 number, 1 special character
  const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
  return passwordRegex.test(password);
};

// Resource type utilities
export const getResourceIcon = (type: string | undefined | null): string => {
  if (!type) {
    return '📚';
  }
  
  switch (type.toLowerCase()) {
    case 'article':
      return '📰';
    case 'video':
      return '🎥';
    case 'exercise':
      return '🧘';
    case 'document':
      return '📄';
    default:
      return '📚';
  }
};

// Crisis detection utilities
export const containsCrisisKeywords = (text: string): boolean => {
  const crisisKeywords = [
    'suicide', 'kill myself', 'end it all', 'hurt myself', 'self harm',
    'want to die', 'better off dead', 'no point living', 'cut myself'
  ];
  
  const lowerText = text.toLowerCase();
  return crisisKeywords.some(keyword => lowerText.includes(keyword));
};

// URL utilities
export const isValidUrl = (string: string): boolean => {
  try {
    new URL(string);
    return true;
  } catch (_) {
    return false;
  }
};

// Array utilities
export const shuffleArray = <T>(array: T[]): T[] => {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
};

// Debounce utility
export const debounce = <T extends (...args: any[]) => any>(
  func: T,
  delay: number
): ((...args: Parameters<T>) => void) => {
  let timeoutId: NodeJS.Timeout;
  
  return (...args: Parameters<T>) => {
    clearTimeout(timeoutId);
    timeoutId = setTimeout(() => func(...args), delay);
  };
};
