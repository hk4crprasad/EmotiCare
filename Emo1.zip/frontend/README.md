# EmotiCare Frontend

A React-based frontend application for EmotiCare - Digital Mental Health and Psychological Support System for Students.

## 🌟 Features

### Core Features
- **User Authentication** - Secure login/registration with JWT tokens
- **AI Chat Support** - Real-time chat with AI counselor for mental health support
- **Mental Health Assessments** - PHQ-9, GAD-7, and other validated assessment tools
- **Appointment Booking** - Schedule sessions with professional counselors
- **Resource Library** - Access to articles, videos, and exercises for mental wellness
- **Peer Support Community** - Anonymous posts and peer interactions
- **Voice Chat** - Voice conversations with AI support using WebSocket
- **Dashboard** - Comprehensive overview of mental health journey

### Design Features
- **Responsive Design** - Works seamlessly on desktop, tablet, and mobile
- **Calming UI** - Specifically designed for stressed students with soothing colors
- **Accessibility** - WCAG compliant with focus management and screen reader support
- **Progressive Enhancement** - Graceful degradation for older browsers
- **Real-time Updates** - Live chat and voice features with WebSocket integration

## 🚀 Quick Start

### Prerequisites
- Node.js 16.x or higher
- npm or yarn package manager
- EmotiCare backend API running on `http://localhost:8000`

### Installation

1. **Clone the repository** (if not already done)
   ```bash
   git clone <repository-url>
   cd EmotiCare/frontend
   ```

2. **Install dependencies**
   ```bash
   npm install
   # or
   yarn install
   ```

3. **Set up environment variables**
   ```bash
   cp .env.example .env.local
   ```
   
   Edit `.env.local` and configure:
   ```env
   REACT_APP_API_URL=http://localhost:8000
   REACT_APP_WS_URL=ws://localhost:8000
   ```

4. **Start the development server**
   ```bash
   npm start
   # or
   yarn start
   ```

5. **Open your browser**
   - Navigate to `http://localhost:3000`
   - The app will automatically reload when you make changes

## 📁 Project Structure

```
frontend/
├── public/
│   ├── index.html
│   └── favicon.ico
├── src/
│   ├── components/          # Reusable UI components
│   │   ├── auth/           # Authentication components
│   │   ├── chat/           # Chat interface components
│   │   ├── dashboard/      # Dashboard components
│   │   ├── layout/         # Layout components
│   │   └── common/         # Shared components
│   ├── pages/              # Main page components
│   │   ├── Assessments.tsx
│   │   ├── Appointments.tsx
│   │   ├── Resources.tsx
│   │   ├── PeerSupport.tsx
│   │   ├── VoiceChat.tsx
│   │   └── Profile.tsx
│   ├── contexts/           # React contexts
│   │   └── AuthContext.tsx
│   ├── services/           # API service layer
│   │   └── api.ts
│   ├── types/              # TypeScript type definitions
│   │   └── index.ts
│   ├── utils/              # Utility functions
│   │   └── index.ts
│   ├── App.tsx             # Main app component
│   ├── index.tsx           # App entry point
│   └── index.css           # Global styles
├── package.json
├── tailwind.config.js
├── tsconfig.json
└── README.md
```

## 🎨 Technology Stack

### Core Technologies
- **React 18** - Frontend framework with hooks and concurrent features
- **TypeScript** - Type-safe JavaScript for better development experience
- **React Router** - Client-side routing and navigation
- **Tailwind CSS** - Utility-first CSS framework for rapid styling

### UI & Animation
- **Framer Motion** - Smooth animations and transitions
- **Heroicons** - Beautiful SVG icons
- **Radix UI** - Accessible headless UI components
- **React Toastify** - Toast notifications

### Data & State Management
- **React Context** - Global state management for authentication
- **Axios** - HTTP client for API communication
- **React Hook Form** - Form validation and management

### Additional Features
- **Chart.js** - Data visualization for assessments
- **WebSocket** - Real-time communication for voice chat
- **Web Speech API** - Browser-based speech recognition and synthesis

## 🔧 Available Scripts

### Development
```bash
npm start          # Start development server
npm test           # Run test suite
npm run build      # Build for production
npm run eject      # Eject from Create React App (irreversible)
```

### Linting & Formatting
```bash
npm run lint       # Run ESLint
npm run lint:fix   # Fix ESLint issues
npm run format     # Format code with Prettier
```

## 🌐 API Integration

The frontend communicates with the EmotiCare backend API through:

### Authentication APIs
- User registration and login
- JWT token management
- Profile updates and password changes

### Mental Health APIs
- Chat sessions with AI counselor
- Mental health assessments (PHQ-9, GAD-7)
- Appointment booking and management
- Resource library access
- Peer support posts

### Real-time Features
- WebSocket connection for voice chat
- Live chat messaging
- Real-time notifications

## 🎯 Key Features for Stressed Students

### Calming Design
- **Soft Color Palette** - Blue and teal tones for stress reduction
- **Gentle Animations** - Smooth transitions that don't overwhelm
- **Clear Typography** - Easy-to-read fonts with appropriate sizing
- **Breathing Space** - Adequate whitespace for visual comfort

### Accessibility Features
- **Crisis Support Alerts** - Immediate access to emergency resources
- **Keyboard Navigation** - Full keyboard accessibility
- **Screen Reader Support** - ARIA labels and semantic HTML
- **High Contrast** - Good color contrast ratios for readability

### User Experience
- **Quick Actions** - Easy access to frequently used features
- **Progress Tracking** - Visual progress indicators for assessments
- **Emotional State Indicators** - Color-coded mood tracking
- **Anonymous Options** - Privacy-first peer support features

## 🔒 Security Features

- **JWT Authentication** - Secure token-based authentication
- **Route Protection** - Protected routes requiring authentication
- **Input Validation** - Client-side validation for all forms
- **Secure Communication** - HTTPS/WSS for all API calls
- **Privacy Controls** - Anonymous posting options

## 📱 Browser Compatibility

### Supported Browsers
- **Chrome** 90+ (recommended)
- **Firefox** 88+
- **Safari** 14+
- **Edge** 90+

### Required Features
- ES6+ JavaScript support
- WebSocket support (for voice chat)
- Web Speech API (for voice features, optional)
- Local Storage (for authentication tokens)

## 🚨 Crisis Support Integration

The application includes built-in crisis support features:

- **Crisis Detection** - Automatic detection of concerning language
- **Emergency Contacts** - Quick access to crisis hotlines
- **Professional Referrals** - Direct links to emergency services
- **Safety Planning** - Resources for crisis management

Emergency contacts available 24/7:
- **Crisis Hotline**: 988
- **Emergency Services**: 911

## 🤝 Contributing

### Development Setup
1. Follow the installation steps above
2. Create a feature branch: `git checkout -b feature/new-feature`
3. Make your changes and test thoroughly
4. Commit with descriptive messages
5. Push and create a pull request

### Code Style
- Use TypeScript for all new components
- Follow the existing component structure
- Write accessible HTML with proper ARIA labels
- Use Tailwind classes for styling
- Add proper error handling and loading states

## 📄 License

This project is part of the EmotiCare mental health support system. Please refer to the main project license for usage terms.

## 📞 Support

For technical support or questions about the EmotiCare frontend:

- **Documentation**: Check this README and inline code comments
- **Issues**: Report bugs through the project issue tracker
- **Development**: Contact the development team for feature requests

---

**Remember**: If you're experiencing a mental health crisis, please contact emergency services immediately at 911 or the Crisis Hotline at 988.
